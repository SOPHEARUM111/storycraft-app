package com.example.aistorystudio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aistorystudio.data.model.Story
import com.example.aistorystudio.data.model.StoryStatus

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    stories: List<Story>,
    onCreateStoryClick: () -> Unit,
    onStoryClick: (Story) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "AI សម្រាយរឿង 🎬",
                        fontWeight = FontWeight.Bold
                    )
                },
                actions = {
                    IconButton(onClick = {}) {
                        Icon(
                            imageVector = Icons.Outlined.Notifications,
                            contentDescription = "Notifications"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Banner
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF6B21A8),
                                    Color(0xFF9333EA)
                                )
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column {
                        Text(
                            text = "សួស្តី អ្នកបង្កើតរឿង 👋",
                            color = Color.White,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "បង្កើតវីដេអូសម្រាយរឿង 9:16 Shorts / TikTok ជាមួយ AI ឆ្លាតវៃ",
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = onCreateStoryClick,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White,
                                contentColor = Color(0xFF6B21A8)
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("create_story_hero_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Create"
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "🎬 បង្កើតសម្រាយរឿងថ្មី",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Workflow pipeline overview
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "⚡ លំហូរការងារ AI Studio",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "🎥 Upload ➔ 🤖 AI Recap ➔ 🎙️ Voice ➔ 📝 Subtitle ➔ 🎬 Render 9:16 ➔ 📤 Share",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Recent Stories Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "រឿងសម្រាយថ្មីៗ",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Stories items
            items(stories) { story ->
                StoryCardItem(story = story, onClick = { onStoryClick(story) })
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun StoryCardItem(
    story: Story,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("story_card_${story.id}"),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "🎬 ${story.title}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    modifier = Modifier.weight(1f)
                )
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (story.status == StoryStatus.COMPLETED)
                        Color(0xFFE8F5E9) else Color(0xFFF3E8FF)
                ) {
                    Text(
                        text = story.status.labelKhmer,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (story.status == StoryStatus.COMPLETED)
                            Color(0xFF2E7D32) else Color(0xFF7C3AED),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(
                    onClick = {},
                    label = { Text("🤖 Script ✓", fontSize = 11.sp) }
                )
                AssistChip(
                    onClick = {},
                    label = { Text("🎙️ Voice ✓", fontSize = 11.sp) }
                )
                AssistChip(
                    onClick = {},
                    label = { Text("🎬 9:16 Shorts", fontSize = 11.sp) }
                )
            }
        }
    }
}
