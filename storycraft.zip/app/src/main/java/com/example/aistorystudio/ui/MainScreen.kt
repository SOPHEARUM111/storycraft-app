package com.example.aistorystudio.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import com.example.aistorystudio.data.model.Story
import com.example.aistorystudio.data.model.StoryStatus
import com.example.aistorystudio.ui.screens.AdminDashboardScreen
import com.example.aistorystudio.ui.screens.CreateStoryScreen
import com.example.aistorystudio.ui.screens.HomeScreen
import com.example.aistorystudio.ui.screens.ProfileScreen
import com.example.aistorystudio.ui.screens.PublishScreen
import com.example.aistorystudio.ui.screens.SettingsScreen
import com.example.aistorystudio.ui.screens.StoriesScreen
import com.example.aistorystudio.ui.screens.StoryDetailScreen

@Composable
fun MainScreen() {
    var currentIndex by remember { mutableIntStateOf(0) }
    var selectedStory by remember { mutableStateOf<Story?>(null) }
    var publishingStory by remember { mutableStateOf<Story?>(null) }
    var isCreatingStory by remember { mutableStateOf(false) }
    var isViewingProfile by remember { mutableStateOf(false) }
    var isViewingAdmin by remember { mutableStateOf(false) }

    val initialStories = remember {
        mutableStateListOf(
            Story(
                id = "1",
                title = "សង្រ្គាមលំហអាកាស ២០២៦ (Space War 2026)",
                script = "សួស្តីបងប្អូនទាំងអស់គ្នា! ថ្ងៃនេះយើងនឹងនាំបងប្អូនមកទស្សនារឿង សង្រ្គាមលំហអាកាស ២០២៦។ រឿងនេះនិយាយពីដំណើរផ្សងព្រេងដ៏អស្ចារ្យ និងអាថ៌កំបាំងដែលមិនធ្លាប់មានពីមុនមក...",
                status = StoryStatus.COMPLETED
            ),
            Story(
                id = "2",
                title = "អាថ៌កំបាំងប្រាសាទបុរាណ (Ancient Temple Secret)",
                script = "ក្រុមអ្នករុករកវ័យក្មេងមួយក្រុម បានរកឃើញច្រកសម្ងាត់ចូលទៅកាន់ប្រាសាទបុរាណ ដែលកប់ក្នុងព្រៃរាប់ពាន់ឆ្នាំ...",
                status = StoryStatus.COMPLETED
            ),
            Story(
                id = "3",
                title = "បេសកកម្មសង្គ្រោះពិភពលោក (Mission Impossible Earth)",
                script = "នៅពេលដែលភពផែនដីជួបប្រទះវិបត្តិធ្ងន់ធ្ងរ កំពូលវីរបុរសត្រូវរួបរួមគ្នាដើម្បីស្វែងរកប្រភពថាមពលថ្មី...",
                status = StoryStatus.GENERATING_VOICE
            )
        )
    }

    if (isViewingProfile) {
        BackHandler {
            isViewingProfile = false
        }
        ProfileScreen(
            onBackClick = { isViewingProfile = false },
            onSaveSuccess = { isViewingProfile = false }
        )
        return
    }

    if (isViewingAdmin) {
        BackHandler {
            isViewingAdmin = false
        }
        AdminDashboardScreen(
            onBackClick = { isViewingAdmin = false }
        )
        return
    }

    if (publishingStory != null) {
        BackHandler {
            publishingStory = null
        }
        PublishScreen(
            story = publishingStory!!,
            onBackClick = { publishingStory = null }
        )
        return
    }

    if (selectedStory != null) {
        BackHandler {
            selectedStory = null
        }
        StoryDetailScreen(
            story = selectedStory!!,
            onBackClick = { selectedStory = null },
            onPublishClick = { publishingStory = selectedStory }
        )
        return
    }

    if (isCreatingStory) {
        BackHandler {
            isCreatingStory = false
        }
        CreateStoryScreen(
            onBackClick = { isCreatingStory = false },
            onStoryCreated = { newStory ->
                initialStories.add(0, newStory)
                isCreatingStory = false
                selectedStory = newStory
            }
        )
        return
    }

    Scaffold(
        bottomBar = {
            NavigationBar(
                modifier = Modifier.testTag("main_bottom_nav_bar")
            ) {
                NavigationBarItem(
                    selected = currentIndex == 0,
                    onClick = { currentIndex = 0 },
                    icon = {
                        Icon(
                            imageVector = if (currentIndex == 0) Icons.Filled.Home else Icons.Outlined.Home,
                            contentDescription = "Home"
                        )
                    },
                    label = { Text("Home") },
                    modifier = Modifier.testTag("nav_home_tab")
                )

                NavigationBarItem(
                    selected = currentIndex == 1,
                    onClick = { currentIndex = 1 },
                    icon = {
                        Icon(
                            imageVector = if (currentIndex == 1) Icons.Filled.VideoLibrary else Icons.Outlined.VideoLibrary,
                            contentDescription = "Stories"
                        )
                    },
                    label = { Text("Stories") },
                    modifier = Modifier.testTag("nav_stories_tab")
                )

                NavigationBarItem(
                    selected = currentIndex == 2,
                    onClick = { currentIndex = 2 },
                    icon = {
                        Icon(
                            imageVector = if (currentIndex == 2) Icons.Filled.Person else Icons.Outlined.Person,
                            contentDescription = "ខ្ញុំ"
                        )
                    },
                    label = { Text("ខ្ញុំ") },
                    modifier = Modifier.testTag("nav_me_tab")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentIndex) {
                0 -> HomeScreen(
                    stories = initialStories,
                    onCreateStoryClick = { isCreatingStory = true },
                    onStoryClick = { story -> selectedStory = story }
                )
                1 -> StoriesScreen(
                    stories = initialStories,
                    onCreateStoryClick = { isCreatingStory = true },
                    onStoryClick = { story -> selectedStory = story }
                )
                2 -> SettingsScreen(
                    onProfileClick = { isViewingProfile = true },
                    onAdminClick = { isViewingAdmin = true },
                    onLogoutClick = {
                        currentIndex = 0
                    }
                )
            }
        }
    }
}
