package com.example.aistorystudio.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aistorystudio.data.model.Story
import com.example.aistorystudio.data.model.StoryStatus

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateStoryScreen(
    onBackClick: () -> Unit,
    onStoryCreated: (Story) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var selectedTone by remember { mutableStateOf("Dramatic (រំភើបញាប់ញ័រ)") }
    var selectedDuration by remember { mutableStateOf("60 វិនាទី (TikTok / Shorts 9:16)") }
    var isSubmitting by remember { mutableStateOf(false) }

    val tones = listOf(
        "Dramatic (រំភើបញាប់ញ័រ) 🔥",
        "Funny (កំប្លែងសើចសប្បាយ) 😂",
        "Mystery (អាថ៌កំបាំងភ័យរន្ធត់) 👻"
    )

    val durations = listOf(
        "60 វិនាទី (TikTok / Shorts 9:16)",
        "90 វិនាទី (Reels / Shorts)",
        "3 នាទី (សម្រាយកម្រិតវែង)"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "បង្កើតសម្រាយរឿងថ្មី 🎬",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier.testTag("back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Text(
                text = "ចំណងជើងរឿង ឬឈ្មោះភាពយន្ត",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                placeholder = { Text("ឧទាហរណ៍៖ សង្រ្គាមលំហអាកាស ២០២៦...") },
                leadingIcon = { Icon(Icons.Default.Movie, contentDescription = null) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("story_title_input"),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Text(
                text = "រចនាបទសំឡេងសម្រាយ (Tone of Voice)",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )

            tones.forEach { tone ->
                Card(
                    onClick = { selectedTone = tone },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (selectedTone == tone)
                            MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = tone,
                        modifier = Modifier.padding(16.dp),
                        fontWeight = if (selectedTone == tone) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }

            Text(
                text = "រយៈពេលគោលដៅ (Target Duration)",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )

            durations.forEach { duration ->
                Card(
                    onClick = { selectedDuration = duration },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (selectedDuration == duration)
                            MaterialTheme.colorScheme.secondaryContainer
                        else MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = duration,
                        modifier = Modifier.padding(16.dp),
                        fontWeight = if (selectedDuration == duration) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        isSubmitting = true
                        val newStory = Story(
                            id = System.currentTimeMillis().toString(),
                            title = title.trim(),
                            script = "សួស្តីបងប្អូនទាំងអស់គ្នា! ថ្ងៃនេះយើងនឹងនាំបងប្អូនមកទស្សនារឿង \"${title.trim()}\"។ រឿងនេះនិយាយពីដំណើរផ្សងព្រេងដ៏អស្ចារ្យ និងអាថ៌កំបាំងដែលមិនធ្លាប់មានពីមុនមក...",
                            tone = selectedTone,
                            duration = selectedDuration,
                            status = StoryStatus.COMPLETED
                        )
                        onStoryCreated(newStory)
                    }
                },
                enabled = title.isNotBlank() && !isSubmitting,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("submit_create_story_btn"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Movie, contentDescription = "Movie Creation")
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "ចាប់ផ្ដើម AI សម្រាយរឿង",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
        }
    }
}
