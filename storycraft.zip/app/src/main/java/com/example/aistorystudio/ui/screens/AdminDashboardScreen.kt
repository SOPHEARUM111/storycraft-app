package com.example.aistorystudio.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class StoryJobItem(
    val id: String,
    val storyId: String,
    val type: String,
    val status: String,
    val attempts: Int = 0,
    val errorMessage: String? = null,
    val createdAt: String = "Just now"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    onBackClick: () -> Unit,
    isAdminUser: Boolean = true
) {
    BackHandler { onBackClick() }

    var showUserManagementDialog by remember { mutableStateOf(false) }
    var showAuditTrailDialog by remember { mutableStateOf(false) }
    var showAdminAlertsDialog by remember { mutableStateOf(false) }
    var userSearchQuery by remember { mutableStateOf("") }
    var searchedUserEmail by remember { mutableStateOf("sophearum.tiger@gmail.com") }
    var isUserBanned by remember { mutableStateOf(false) }

    // Mock/Sample Story Jobs for live monitoring
    val jobs = remember {
        mutableStateListOf(
            StoryJobItem(
                id = "job_1",
                storyId = "story_space_war",
                type = "render_video",
                status = "completed",
                attempts = 1
            ),
            StoryJobItem(
                id = "job_2",
                storyId = "story_ancient_temple",
                type = "generate_subtitle",
                status = "completed",
                attempts = 1
            ),
            StoryJobItem(
                id = "job_3",
                storyId = "story_cyber_mission",
                type = "generate_voice",
                status = "processing",
                attempts = 1
            ),
            StoryJobItem(
                id = "job_4",
                storyId = "story_failed_sample",
                type = "render_video",
                status = "error",
                attempts = 2,
                errorMessage = "FFmpeg Timeout: video dimensions unsupported"
            ),
            StoryJobItem(
                id = "job_5",
                storyId = "story_queued_sample",
                type = "extract_audio",
                status = "queued",
                attempts = 0
            ),
            StoryJobItem(
                id = "job_6",
                storyId = "story_stale_sample",
                type = "transcribe",
                status = "stale",
                attempts = 1
            )
        )
    }

    if (!isAdminUser) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Admin Dashboard") },
                    navigationIcon = {
                        IconButton(onClick = onBackClick) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                )
            }
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "No Access",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "អ្នកមិនមានសិទ្ធិ Admin ទេ។",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
        return
    }

    val totalCount = jobs.size
    val processingCount = jobs.count { it.status == "processing" }
    val completedCount = jobs.count { it.status == "completed" }
    val errorCount = jobs.count { it.status == "error" }
    val staleCount = jobs.count { it.status == "stale" }
    val queuedCount = jobs.count { it.status == "queued" }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("👑 Admin Dashboard", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Queue & Worker Analytics", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick, modifier = Modifier.testTag("admin_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { /* Refresh */ }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = "📊 ស្ថិតិ Jobs 50 ចុងក្រោយ",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            // Stat Cards Grid (AdminStatsPanel)
            item {
                AdminStatsPanel(
                    totalCount = totalCount,
                    processingCount = processingCount,
                    completedCount = completedCount,
                    errorCount = errorCount,
                    staleCount = staleCount,
                    queuedCount = queuedCount
                )
            }

            // 👥 User Management Navigation Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showUserManagementDialog = true }
                        .testTag("admin_manage_users_card"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                ) {
                    ListItem(
                        leadingContent = {
                            Icon(
                                imageVector = Icons.Default.ManageAccounts,
                                contentDescription = "Manage Accounts",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        },
                        headlineContent = {
                            Text(
                                text = "គ្រប់គ្រងអ្នកប្រើប្រាស់",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        },
                        supportingContent = {
                            Text(
                                text = "ស្វែងរក និងគ្រប់គ្រងស្ថានភាពគណនី",
                                fontSize = 12.sp
                            )
                        },
                        trailingContent = {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                                contentDescription = "Open",
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    )
                }
            }

            // 📜 Admin Audit Trail Navigation Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showAuditTrailDialog = true }
                        .testTag("admin_audit_trail_card"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                ) {
                    ListItem(
                        leadingContent = {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = "Audit History",
                                tint = Color(0xFFA855F7)
                            )
                        },
                        headlineContent = {
                            Text(
                                text = "ប្រវត្តិសកម្មភាព Admin",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        },
                        supportingContent = {
                            Text(
                                text = "ពិនិត្យការបិទ និងបើកគណនី",
                                fontSize = 12.sp
                            )
                        },
                        trailingContent = {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                                contentDescription = "Open",
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    )
                }
            }

            // 🔔 Admin Alerts Navigation Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showAdminAlertsDialog = true }
                        .testTag("admin_alerts_card"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                ) {
                    ListItem(
                        leadingContent = {
                            Icon(
                                imageVector = Icons.Default.NotificationsActive,
                                contentDescription = "Admin Alerts",
                                tint = Color(0xFFF59E0B)
                            )
                        },
                        headlineContent = {
                            Text(
                                text = "Admin Alerts",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        },
                        supportingContent = {
                            Text(
                                text = "មើលបញ្ហា និងការជូនដំណឹង",
                                fontSize = 12.sp
                            )
                        },
                        trailingContent = {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                                contentDescription = "Open",
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "🎬 Jobs ថ្មីៗក្នុងប្រព័ន្ធ",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            items(jobs) { job ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Movie,
                                    contentDescription = "Job",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = job.type,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = when (job.status) {
                                    "completed" -> Color(0xFF10B981).copy(alpha = 0.2f)
                                    "error" -> Color(0xFFEF4444).copy(alpha = 0.2f)
                                    "processing" -> Color(0xFF38BDF8).copy(alpha = 0.2f)
                                    "stale" -> Color(0xFFF59E0B).copy(alpha = 0.2f)
                                    else -> Color.Gray.copy(alpha = 0.2f)
                                }
                            ) {
                                Text(
                                    text = job.status.uppercase(),
                                    color = when (job.status) {
                                        "completed" -> Color(0xFF10B981)
                                        "error" -> Color(0xFFEF4444)
                                        "processing" -> Color(0xFF38BDF8)
                                        "stale" -> Color(0xFFF59E0B)
                                        else -> Color.Gray
                                    },
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Text(
                            text = "Story: ${job.storyId}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        if (!job.errorMessage.isNullOrBlank()) {
                            Text(
                                text = "⚠️ Error: ${job.errorMessage}",
                                fontSize = 11.sp,
                                color = Color(0xFFF87171)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showUserManagementDialog) {
        AlertDialog(
            onDismissRequest = { showUserManagementDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ManageAccounts,
                        contentDescription = "Manage",
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "គ្រប់គ្រងអ្នកប្រើប្រាស់",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = userSearchQuery,
                        onValueChange = { userSearchQuery = it },
                        label = { Text("អ៊ីមែល ឬ UID") },
                        placeholder = { Text("user@example.com") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Button(
                        onClick = {
                            if (userSearchQuery.isNotBlank()) {
                                searchedUserEmail = userSearchQuery.trim()
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Search, contentDescription = "Search")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("ស្វែងរកគណនី")
                    }

                    HorizontalDivider()

                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "👤 គណនី: $searchedUserEmail",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "ស្ថានភាព: " + if (isUserBanned) "🚫 បានបិទ (Banned)" else "✅ សកម្ម (Active)",
                                fontSize = 12.sp,
                                color = if (isUserBanned) MaterialTheme.colorScheme.error else Color(0xFF10B981),
                                fontWeight = FontWeight.Bold
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            OutlinedButton(
                                onClick = { isUserBanned = !isUserBanned },
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = if (isUserBanned) Color(0xFF10B981) else MaterialTheme.colorScheme.error
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(
                                    imageVector = if (isUserBanned) Icons.Default.LockOpen else Icons.Default.Block,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (isUserBanned) "បើកគណនីវិញ" else "បិទគណនី (Ban User)")
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showUserManagementDialog = false }) {
                    Text("បិទ")
                }
            }
        )
    }

    if (showAuditTrailDialog) {
        AlertDialog(
            onDismissRequest = { showAuditTrailDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "Audit History",
                        tint = Color(0xFFA855F7)
                    )
                    Text(
                        text = "ប្រវត្តិសកម្មភាព Admin",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "📜 កំណត់ត្រាសវនកម្មចុងក្រោយ (Audit Trail)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    val sampleLogs = listOf(
                        Triple("user_disabled", "spammer@example.com", "2026-10-09 14:12"),
                        Triple("user_enabled", "user102@example.com", "2026-10-09 11:45"),
                        Triple("user_disabled", "bot99@example.com", "2026-10-08 18:30")
                    )

                    sampleLogs.forEach { (action, target, time) ->
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = if (action == "user_disabled") "🚫 បានបិទគណនី" else "✅ បានបើកគណនីឡើងវិញ",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = if (action == "user_disabled") MaterialTheme.colorScheme.error else Color(0xFF10B981)
                                    )
                                    Text(text = time, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text(text = "គណនីគោលដៅ: $target", fontSize = 11.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAuditTrailDialog = false }) {
                    Text("បិទ")
                }
            }
        )
    }

    if (showAdminAlertsDialog) {
        AlertDialog(
            onDismissRequest = { showAdminAlertsDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.NotificationsActive,
                        contentDescription = "Admin Alerts",
                        tint = Color(0xFFF59E0B)
                    )
                    Text(
                        text = "Admin Alerts",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "🔔 ការជូនដំណឹងបញ្ហាប្រព័ន្ធ (System Incident Queue)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    val alertsList = remember {
                        mutableStateListOf(
                            Triple("job_failed", "Story processing failed", "Job job_404 failed. Please review the error logs."),
                            Triple("job_stuck", "Heartbeat Timeout", "Job job_212 worker inactive > 60s."),
                            Triple("job_recovered", "Job auto-retried", "Job job_101 retried successfully.")
                        )
                    }

                    if (alertsList.isEmpty()) {
                        Text(
                            text = "✅ គ្មានការជូនដំណឹងនៅសេសសល់ទេ",
                            fontSize = 13.sp,
                            color = Color(0xFF10B981)
                        )
                    } else {
                        alertsList.forEachIndexed { index, (type, title, message) ->
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = title,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = when (type) {
                                                "job_failed" -> MaterialTheme.colorScheme.error
                                                "job_stuck" -> Color(0xFFF59E0B)
                                                else -> Color(0xFF10B981)
                                            }
                                        )
                                        IconButton(
                                            onClick = { alertsList.removeAt(index) },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Done,
                                                contentDescription = "Acknowledge",
                                                tint = Color(0xFF10B981),
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                    Text(text = message, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAdminAlertsDialog = false }) {
                    Text("បិទ")
                }
            }
        )
    }
}

/**
 * 📊 AdminStatsPanel Composable
 */
@Composable
fun AdminStatsPanel(
    totalCount: Int,
    processingCount: Int,
    completedCount: Int,
    errorCount: Int,
    staleCount: Int,
    queuedCount: Int,
    avgDurationSec: Float = 14.2f,
    onRefreshClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Latency Banner
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = "Speed",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "ល្បឿនមធ្យមនៃ Render Video (Latency)",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                    Text(
                        text = "${String.format("%.1f", avgDurationSec)}s ក្នុង 1 Job",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
                IconButton(onClick = onRefreshClick) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Refresh",
                        tint = Color.White.copy(alpha = 0.8f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // 6 Grid Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AdminStatCard(
                label = "Jobs សរុប",
                value = totalCount.toString(),
                icon = Icons.Default.Work,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.weight(1f)
            )
            AdminStatCard(
                label = "កំពុងដំណើរការ",
                value = processingCount.toString(),
                icon = Icons.Default.Sync,
                color = Color(0xFF38BDF8),
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AdminStatCard(
                label = "បានបញ្ចប់",
                value = completedCount.toString(),
                icon = Icons.Default.CheckCircle,
                color = Color(0xFF10B981),
                modifier = Modifier.weight(1f)
            )
            AdminStatCard(
                label = "បរាជ័យ (Error)",
                value = errorCount.toString(),
                icon = Icons.Default.Error,
                color = Color(0xFFEF4444),
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AdminStatCard(
                label = "ជាប់គាំង (Stale)",
                value = staleCount.toString(),
                icon = Icons.Default.Warning,
                color = Color(0xFFF59E0B),
                modifier = Modifier.weight(1f)
            )
            AdminStatCard(
                label = "រង់ចាំ (Queued)",
                value = queuedCount.toString(),
                icon = Icons.Default.HourglassEmpty,
                color = Color(0xFFA855F7),
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
fun AdminStatCard(
    label: String,
    value: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = color,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = label,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
