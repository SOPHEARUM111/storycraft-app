package com.example.aistorystudio.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.aistorystudio.data.model.Story
import com.example.aistorystudio.data.model.StoryStatus

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoriesScreen(
    stories: List<Story>,
    onCreateStoryClick: () -> Unit,
    onStoryClick: (Story) -> Unit
) {
    var selectedFilter by remember { mutableStateOf("all") }

    val filteredStories = remember(stories, selectedFilter) {
        when (selectedFilter) {
            "completed" -> stories.filter { it.status == StoryStatus.COMPLETED }
            "processing" -> stories.filter { it.status != StoryStatus.COMPLETED }
            else -> stories
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "រឿងសម្រាយរបស់ខ្ញុំ 📚",
                        fontWeight = FontWeight.Bold
                    )
                },
                actions = {
                    IconButton(
                        onClick = onCreateStoryClick,
                        modifier = Modifier.testTag("add_story_action")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "New Story",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = selectedFilter == "all",
                        onClick = { selectedFilter = "all" },
                        label = { Text("📚 ទាំងអស់ (${stories.size})") }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedFilter == "processing",
                        onClick = { selectedFilter = "processing" },
                        label = { Text("⏳ កំពុងដំណើរការ") }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedFilter == "completed",
                        onClick = { selectedFilter = "completed" },
                        label = { Text("✅ រួចរាល់") }
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredStories) { story ->
                    StoryCardItem(
                        story = story,
                        onClick = { onStoryClick(story) }
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}
