package com.example.aistorystudio.data.model

data class Story(
    val id: String,
    val userId: String = "USER_ID",
    val title: String,
    val sourceVideoPath: String = "",
    val sourceAudioPath: String? = null,
    val status: StoryStatus = StoryStatus.COMPLETED,
    val processingStep: String = "completed",
    val processingProgress: Int = 100,
    val transcript: String = "",
    val script: String = "",
    val audioPath: String? = null,
    val subtitlePath: String? = null,
    val finalVideoPath: String? = null,
    val finalVideoUrl: String = "",
    val errorMessage: String? = null,
    val socialTitle: String = "",
    val socialDescription: String = "",
    val hashtags: String = "#សម្រាយរឿង #TheLastDay #Shorts #TikTok #Reels",
    val tags: String = "សម្រាយរឿង, movie recap khmer, The Last Day, shorts, tiktok",
    val socialStatus: String = "ready",
    val tone: String = "Dramatic (រំភើបញាប់ញ័រ)",
    val duration: String = "60 វិនាទី (TikTok / Shorts 9:16)",
    val createdAt: String = "ថ្ងៃនេះ",
    val updatedAt: String = "ថ្ងៃនេះ"
)

enum class StoryStatus(val key: String, val labelKhmer: String, val labelEnglish: String, val progress: Float) {
    QUEUED("queued", "⏳ កំពុងរង់ចាំ", "Queued", 0.0f),
    PROCESSING("processing", "⚙️ កំពុងដំណើរការ", "Processing", 0.10f),
    UPLOADING("uploading", "📤 កំពុង Upload", "Uploading", 0.15f),
    TRANSCRIBING("transcribing", "🎧 កំពុងស្តាប់សំឡេង", "Transcribing", 0.35f),
    GENERATING_RECAP("generating_recap", "🤖 កំពុងសម្រាយរឿង", "Generating Recap", 0.55f),
    GENERATING_VOICE("generating_voice", "🎙️ កំពុងបង្កើត AI Voice", "Generating Voice", 0.70f),
    GENERATING_SUBTITLE("generating_subtitle", "📝 កំពុងបង្កើត Subtitle", "Generating Subtitles", 0.85f),
    RENDERING_VIDEO("rendering_video", "🎬 កំពុង Render 9:16", "Rendering 9:16", 0.95f),
    COMPLETED("completed", "✅ រួចរាល់ ១០០%", "Completed", 1.0f),
    ERROR("error", "❌ មានបញ្ហា", "Error", 0.0f)
}
