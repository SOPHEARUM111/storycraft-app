package com.example.aistorystudio.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF9333EA),
    onPrimary = Color.White,
    primaryContainer = Color(0xFF6B21A8),
    onPrimaryContainer = Color.White,
    secondary = Color(0xFFC084FC),
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF3B0764),
    onSecondaryContainer = Color.White,
    background = Color(0xFF0F0E17),
    onBackground = Color(0xFFEDEDED),
    surface = Color(0xFF181726),
    onSurface = Color(0xFFEDEDED),
    surfaceVariant = Color(0xFF232136),
    onSurfaceVariant = Color(0xFFD4D4D8),
    outline = Color(0xFF3F3C56),
    error = Color(0xFFEF4444),
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF7C3AED),
    secondary = Color(0xFF625B71),
    tertiary = Color(0xFF7D5260),
    background = Color(0xFFFBFBFE),
    surface = Color(0xFFFFFFFF)
)

@Composable
fun AIStoryStudioTheme(
    darkTheme: Boolean = true, // 🌙 តែងតាំង Dark Mode ជាលំនាំដើម
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
