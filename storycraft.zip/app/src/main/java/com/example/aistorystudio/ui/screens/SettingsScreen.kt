package com.example.aistorystudio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onProfileClick: () -> Unit = {},
    onLogoutClick: () -> Unit = {},
    onAdminClick: () -> Unit = {}
) {
    var notificationsEnabled by remember { mutableStateOf(true) }
    var selectedLanguage by remember { mutableStateOf("ខ្មែរ (Khmer)") }
    var selectedTheme by remember { mutableStateOf("System Default (តាមប្រព័ន្ធ)") }

    var showPasswordDialog by remember { mutableStateOf(false) }
    var showLanguageDialog by remember { mutableStateOf(false) }
    var showThemeDialog by remember { mutableStateOf(false) }
    var showLogoutDialog by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }
    var snackbarMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let {
            snackbarHostState.showSnackbar(it)
            snackbarMessage = null
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "⚙️ Settings",
                        fontWeight = FontWeight.Bold
                    )
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .testTag("settings_screen_list")
        ) {
            // Profile Header
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable(onClick = onProfileClick)
                        .padding(vertical = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(90.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "User Avatar",
                            modifier = Modifier.size(50.dp),
                            tint = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "AI Creator (អ្នកបង្កើតរឿង)",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "sophearum.tiger@gmail.com",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
            }

            // ⚙️ Settings Items
            item {
                Text(
                    text = "ការកំណត់គណនី និងកម្មវិធី",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))

                // 👤 Profile
                SettingsItem(
                    icon = Icons.Outlined.Person,
                    title = "👤 Profile",
                    subtitle = "កែប្រែព័ត៌មានគណនី",
                    onClick = onProfileClick
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                // 👑 Admin Dashboard
                SettingsItem(
                    icon = Icons.Outlined.AdminPanelSettings,
                    title = "👑 Admin Dashboard",
                    subtitle = "ត្រួតពិនិត្យ Jobs & Worker Queue Analytics",
                    onClick = onAdminClick
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                // 🔐 Password
                SettingsItem(
                    icon = Icons.Outlined.Lock,
                    title = "🔐 Password",
                    subtitle = "ប្តូរពាក្យសម្ងាត់គណនី",
                    onClick = { showPasswordDialog = true }
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                // 🌐 Language
                SettingsItem(
                    icon = Icons.Outlined.Language,
                    title = "🌐 Language",
                    subtitle = selectedLanguage,
                    onClick = { showLanguageDialog = true }
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                // 🌙 Theme
                SettingsItem(
                    icon = Icons.Outlined.DarkMode,
                    title = "🌙 Theme",
                    subtitle = selectedTheme,
                    onClick = { showThemeDialog = true }
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                // 🔔 Notifications
                ListItem(
                    headlineContent = { Text("🔔 Notifications") },
                    supportingContent = { Text("ការជូនដំណឹងពេល Render រួចរាល់") },
                    leadingContent = {
                        Icon(
                            imageVector = Icons.Outlined.Notifications,
                            contentDescription = "Notifications"
                        )
                    },
                    trailingContent = {
                        Switch(
                            checked = notificationsEnabled,
                            onCheckedChange = {
                                notificationsEnabled = it
                                snackbarMessage = if (it) "បានបើកការជូនដំណឹង 🔔" else "បានបិទការជូនដំណឹង 🔕"
                            },
                            modifier = Modifier.testTag("notification_switch")
                        )
                    }
                )

                Spacer(modifier = Modifier.height(28.dp))
            }

            // 🚪 Logout Button
            item {
                OutlinedButton(
                    onClick = { showLogoutDialog = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("logout_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Logout,
                        contentDescription = "Logout Icon",
                        tint = MaterialTheme.colorScheme.error
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "🚪 Logout (ចាកចេញពីគណនី)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // 🔐 Change Password Dialog
    if (showPasswordDialog) {
        var oldPassword by remember { mutableStateOf("") }
        var newPassword by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showPasswordDialog = false },
            title = { Text("🔐 ប្តូរពាក្យសម្ងាត់") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = oldPassword,
                        onValueChange = { oldPassword = it },
                        label = { Text("ពាក្យសម្ងាត់ចាស់") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newPassword,
                        onValueChange = { newPassword = it },
                        label = { Text("ពាក្យសម្ងាត់ថ្មី") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showPasswordDialog = false
                        snackbarMessage = "បានប្តូរពាក្យសម្ងាត់ដោយជោគជ័យ! ✅"
                    }
                ) {
                    Text("ប្តូរ")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPasswordDialog = false }) {
                    Text("បោះបង់")
                }
            }
        )
    }

    // 🌐 Language Dialog
    if (showLanguageDialog) {
        val languages = listOf("ខ្មែរ (Khmer)", "English (US)", "中文 (Chinese)")
        AlertDialog(
            onDismissRequest = { showLanguageDialog = false },
            title = { Text("🌐 ជ្រើសរើសភាសា (Language)") },
            text = {
                Column {
                    languages.forEach { lang ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedLanguage = lang
                                    showLanguageDialog = false
                                    snackbarMessage = "បានជ្រើសរើសភាសា៖ $lang"
                                }
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedLanguage == lang,
                                onClick = {
                                    selectedLanguage = lang
                                    showLanguageDialog = false
                                    snackbarMessage = "បានជ្រើសរើសភាសា៖ $lang"
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(lang, fontSize = 15.sp)
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }

    // 🌙 Theme Dialog
    if (showThemeDialog) {
        val themes = listOf("System Default (តាមប្រព័ន្ធ)", "Light Mode (ពន្លឺ)", "Dark Mode (ងងឹត)")
        AlertDialog(
            onDismissRequest = { showThemeDialog = false },
            title = { Text("🌙 ជ្រើសរើស Theme") },
            text = {
                Column {
                    themes.forEach { theme ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedTheme = theme
                                    showThemeDialog = false
                                    snackbarMessage = "បានកំណត់ Theme៖ $theme"
                                }
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedTheme == theme,
                                onClick = {
                                    selectedTheme = theme
                                    showThemeDialog = false
                                    snackbarMessage = "បានកំណត់ Theme៖ $theme"
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(theme, fontSize = 15.sp)
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }

    // 🚪 Logout Dialog
    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            title = { Text("🚪 ចាកចេញពីគណនី?") },
            text = { Text("តើអ្នកពិតជាចង់ចាកចេញពីគណនី AI Story Studio នេះមែនទេ?") },
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutDialog = false
                        onLogoutClick()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Text("ចាកចេញ")
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutDialog = false }) {
                    Text("បោះបង់")
                }
            }
        )
    }
}

@Composable
private fun SettingsItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    ListItem(
        modifier = Modifier.clickable(onClick = onClick),
        leadingContent = {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        },
        headlineContent = {
            Text(
                text = title,
                fontWeight = FontWeight.Medium
            )
        },
        supportingContent = {
            Text(
                text = subtitle,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 13.sp
            )
        },
        trailingContent = {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                contentDescription = "Navigate",
                modifier = Modifier.size(16.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    )
}
