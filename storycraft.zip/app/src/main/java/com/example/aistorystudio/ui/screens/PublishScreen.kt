package com.example.aistorystudio.ui.screens

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aistorystudio.data.model.Story

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PublishScreen(
    story: Story,
    onBackClick: () -> Unit
) {
    BackHandler { onBackClick() }

    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val snackbarHostState = remember { SnackbarHostState() }
    var snackbarMessage by remember { mutableStateOf<String?>(null) }

    var isPlaying by remember { mutableStateOf(false) }
    var currentPositionSec by remember { mutableFloatStateOf(0f) }
    val totalDurationSec = 60f

    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            kotlinx.coroutines.delay(100)
            if (currentPositionSec >= totalDurationSec) {
                currentPositionSec = 0f
                isPlaying = false
            } else {
                currentPositionSec += 0.1f
            }
        }
    }

    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            snackbarMessage = null
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "🚀 បង្ហោះវីដេអូ (Publish Hub)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = story.title,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier.testTag("publish_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 🎬 9:16 Shorts Video Player Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(340.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF0F172A)
                )
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    // Vertical 9:16 Canvas Mock
                    Column(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
                                .clickable { isPlaying = !isPlaying },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                contentDescription = if (isPlaying) "Pause" else "Play",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(40.dp)
                            )
                        }

                        Text(
                            text = if (isPlaying) "កំពុងចាក់វីដេអូ 9:16..." else "ចុចដើម្បីទស្សនាវីដេអូសម្រាយរឿង",
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 13.sp
                        )

                        // Subtitle preview
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color.Black.copy(alpha = 0.6f),
                            modifier = Modifier.padding(horizontal = 16.dp)
                        ) {
                            Text(
                                text = "បុរសម្នាក់ត្រូវប្រឈមមុខនឹងគ្រោះថ្នាក់ដ៏ធំធេង...",
                                color = Color(0xFFFDE047),
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }

                    // Progress Controls at bottom
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .padding(12.dp)
                    ) {
                        Slider(
                            value = currentPositionSec,
                            onValueChange = { currentPositionSec = it },
                            valueRange = 0f..totalDurationSec,
                            colors = SliderDefaults.colors(
                                thumbColor = MaterialTheme.colorScheme.primary,
                                activeTrackColor = MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${currentPositionSec.toInt()}s / ${totalDurationSec.toInt()}s",
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 12.sp
                            )

                            // Restart to 00:00 Button
                            TextButton(
                                onClick = {
                                    currentPositionSec = 0f
                                    isPlaying = true
                                },
                                modifier = Modifier.testTag("publish_restart_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Restart",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("00:00 Restart", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // 💾 Save to Album & Quick Share Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        snackbarMessage = "✅ បានរក្សាទុកក្នុង Album 'Story Recap AI' រួចរាល់!"
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("save_to_album_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.Download, contentDescription = "Download")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Save to Album")
                }

                FilledTonalButton(
                    onClick = {
                        val shareText = "${story.socialTitle.ifBlank { story.title }}\n\n${story.socialDescription}\n\n${story.hashtags}"
                        val sendIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, shareText)
                            type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(sendIntent, "Share Story"))
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("share_video_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.Share, contentDescription = "Share")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Share Direct")
                }
            }

            // 📋 Social Kit 1-Tap Copy Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "📋 កញ្ចប់ Social Media Kit",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )

                        TextButton(
                            onClick = {
                                val fullKit = "ចំណងជើង: ${story.socialTitle.ifBlank { story.title }}\n\nCaption: ${story.socialDescription}\n\nHashtags: ${story.hashtags}\n\nTags: ${story.tags}"
                                clipboardManager.setText(AnnotatedString(fullKit))
                                snackbarMessage = "📋 បានចម្លងកញ្ចប់ Social Kit ទាំងអស់រួចរាល់!"
                            },
                            modifier = Modifier.testTag("copy_all_kit_button")
                        ) {
                            Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy All", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Copy All", fontSize = 13.sp)
                        }
                    }

                    // Title Field
                    OutlinedCard(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("ចំណងជើង (Hook Title)", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                                Text(
                                    text = story.socialTitle.ifBlank { story.title },
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 14.sp
                                )
                            }
                            IconButton(onClick = {
                                clipboardManager.setText(AnnotatedString(story.socialTitle.ifBlank { story.title }))
                                snackbarMessage = "📋 បានចម្លងចំណងជើង!"
                            }) {
                                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy Title")
                            }
                        }
                    }

                    // Caption Field
                    OutlinedCard(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Caption Teaser", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                                Text(
                                    text = story.socialDescription.ifBlank { "តើអ្នកនឹងធ្វើដូចម្តេច ប្រសិនបើរឿងនេះកើតឡើងចំពោះអ្នក? 🔥" },
                                    fontSize = 13.sp
                                )
                            }
                            IconButton(onClick = {
                                clipboardManager.setText(AnnotatedString(story.socialDescription))
                                snackbarMessage = "📋 បានចម្លង Caption!"
                            }) {
                                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy Caption")
                            }
                        }
                    }

                    // Hashtags
                    OutlinedCard(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Hashtags", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                                Text(
                                    text = story.hashtags.ifBlank { "#សម្រាយរឿង #MovieRecap #Khmer #Shorts" },
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            IconButton(onClick = {
                                clipboardManager.setText(AnnotatedString(story.hashtags))
                                snackbarMessage = "📋 បានចម្លង Hashtags!"
                            }) {
                                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy Hashtags")
                            }
                        }
                    }
                }
            }

            // 🚀 Social Platform Shortcuts
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "🚀 ចែករំលែកទៅកាន់ Platform ផ្ទាល់",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilledTonalButton(
                            onClick = {
                                snackbarMessage = "កំពុងបើក TikTok..."
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("📱 TikTok")
                        }

                        FilledTonalButton(
                            onClick = {
                                snackbarMessage = "កំពុងបើក Facebook Reels..."
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("🔥 Reels")
                        }

                        FilledTonalButton(
                            onClick = {
                                snackbarMessage = "កំពុងបើក YouTube Shorts..."
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("🎬 Shorts")
                        }
                    }
                }
            }
        }
    }
}
