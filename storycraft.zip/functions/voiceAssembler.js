const { assembleVoiceChunks } = require("./voice_assembler");

module.exports = { assembleVoiceChunks };
