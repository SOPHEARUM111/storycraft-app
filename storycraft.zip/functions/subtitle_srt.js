const admin = require("firebase-admin");
const { buildSrt } = require("./srt_builder");

if (!admin.apps.length) {
  admin.initializeApp();
}

async function saveStorySubtitle(storyId, segments) {
  const srt = buildSrt(segments);
  const storagePath = `stories/${storyId}/subtitles/final.srt`;

  const bucket = admin.storage().bucket();

  await bucket.file(storagePath).save(
    Buffer.from(srt, "utf8"),
    {
      resumable: false,
      metadata: {
        contentType: "application/x-subrip; charset=utf-8",
        cacheControl: "private, no-store",
      },
    }
  );

  await admin.firestore()
    .collection("stories")
    .doc(storyId)
    .update({
      subtitlePath: storagePath,
      subtitleStatus: "completed",
      processingStep: "subtitle_completed",
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });

  return {
    subtitlePath: storagePath,
    subtitleCount: segments.length,
    subtitleStatus: "completed",
  };
}

module.exports = { buildSrt, saveStorySubtitle };
