/**
 * 👑 Script ផ្តល់សិទ្ធិ Admin (Firebase Custom User Claims)
 * របៀបរត់: node scripts/grantAdmin.js <FIREBASE_AUTH_UID>
 */
const admin = require("firebase-admin");

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.applicationDefault(),
  });
}

async function grantAdmin(uid) {
  if (!uid || uid === "YOUR_ADMIN_UID") {
    console.error("❌ សូមបញ្ជាក់ Firebase Auth UID ជាក់ស្តែង (ឧ. node scripts/grantAdmin.js abc123xyz)");
    process.exit(1);
  }

  console.log(`⏳ កំពុងផ្តល់សិទ្ធិ Admin ដល់ UID: ${uid}...`);

  await admin.auth().setCustomUserClaims(uid, {
    admin: true,
  });

  // ផ្ទៀងផ្ទាត់ឡើងវិញ (Verification)
  const user = await admin.auth().getUser(uid);
  console.log("✅ Admin access granted successfully!");
  console.log(`👤 User Email: ${user.email}`);
  console.log(`🔑 Custom Claims:`, user.customClaims);
}

// ទទួល UID ពី Command-line Argument ឬ Fallback
const targetUid = process.argv[2] || "YOUR_ADMIN_UID";
grantAdmin(targetUid).catch((err) => {
  console.error("❌ បរាជ័យក្នុងការផ្តល់សិទ្ធិ:", err.message || err);
  process.exit(1);
});
