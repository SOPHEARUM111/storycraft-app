function normalizeForComparison(text) {
  return text
    .normalize("NFKC")
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .trim();
}

function assembleScriptChunks(chunks) {
  if (!Array.isArray(chunks) || chunks.length === 0) {
    throw new Error("No script chunks were provided.");
  }

  const ordered = [...chunks].sort(
    (a, b) => a.chunkIndex - b.chunkIndex
  );

  const seen = new Set();
  const output = [];
  let removedDuplicates = 0;

  for (let i = 0; i < ordered.length; i++) {
    const chunk = ordered[i];

    if (
      chunk.status !== "completed" ||
      typeof chunk.script !== "string" ||
      !chunk.script.trim()
    ) {
      throw new Error(
        `Chunk ${chunk.chunkIndex} is incomplete.`
      );
    }

    // Keep chunk order and split into paragraphs.
    const paragraphs = chunk.script
      .trim()
      .split(/\n\s*\n/)
      .map((p) => p.trim())
      .filter(Boolean);

    for (const paragraph of paragraphs) {
      const key = normalizeForComparison(paragraph);

      // Remove exact normalized paragraph duplicates only.
      if (key && seen.has(key)) {
        removedDuplicates++;
        continue;
      }

      if (key) seen.add(key);
      output.push(paragraph);
    }
  }

  const script = output.join("\n\n").trim();

  if (!script) {
    throw new Error("Assembled script is empty.");
  }

  return {
    script,
    chunkCount: ordered.length,
    removedDuplicates,
    characterCount: script.length,
    qualityStatus: removedDuplicates > 0
      ? "review_recommended"
      : "passed_basic_checks",
  };
}

module.exports = { assembleScriptChunks };
