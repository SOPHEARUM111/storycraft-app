const DEFAULT_WORDS_PER_MINUTE = 120;
const MAX_TARGET_MINUTES = 90;
const CHUNK_MINUTES = 5;

function calculateScriptPlan(
  targetMinutes,
  wordsPerMinute = DEFAULT_WORDS_PER_MINUTE
) {
  if (
    !Number.isInteger(targetMinutes) ||
    targetMinutes < 1 ||
    targetMinutes > MAX_TARGET_MINUTES
  ) {
    throw new Error(
      "Duration must be between 1 and 90 minutes."
    );
  }

  if (
    !Number.isFinite(wordsPerMinute) ||
    wordsPerMinute < 60 ||
    wordsPerMinute > 180
  ) {
    throw new Error("Invalid narration speed.");
  }

  const targetWords = Math.round(
    targetMinutes * wordsPerMinute
  );

  const sectionCount = Math.ceil(
    targetMinutes / CHUNK_MINUTES
  );

  return {
    targetMinutes,
    wordsPerMinute,
    targetWords,
    sectionCount,
    chunkMinutes: CHUNK_MINUTES,
  };
}

module.exports = { calculateScriptPlan };
