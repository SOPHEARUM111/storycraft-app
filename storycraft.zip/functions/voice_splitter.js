function splitScriptForVoice(script, maxChars = 3000) {
  if (typeof script !== "string" || !script.trim()) {
    throw new Error("Script is empty.");
  }

  const paragraphs = script
    .split(/\n\s*\n/)
    .map((p) => p.trim())
    .filter(Boolean);

  const chunks = [];
  let current = "";

  for (const paragraph of paragraphs) {
    if (paragraph.length > maxChars) {
      if (current) {
        chunks.push(current);
        current = "";
      }

      // Split long paragraphs near sentence boundaries.
      const sentences = paragraph.match(/[^.!?។៕]+[.!?។៕]?/g) || [paragraph];

      for (const sentence of sentences) {
        const part = sentence.trim();
        if (!part) continue;

        if ((current + " " + part).trim().length > maxChars) {
          if (current) chunks.push(current);
          current = part;
        } else {
          current = (current + " " + part).trim();
        }
      }
      continue;
    }

    if ((current + "\n\n" + paragraph).trim().length > maxChars) {
      if (current) chunks.push(current);
      current = paragraph;
    } else {
      current = (current + "\n\n" + paragraph).trim();
    }
  }

  if (current) chunks.push(current);
  return chunks;
}

module.exports = { splitScriptForVoice };
