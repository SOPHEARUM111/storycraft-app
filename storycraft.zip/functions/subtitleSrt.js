const { buildSrt, saveStorySubtitle } = require("./subtitle_srt");

module.exports = { buildSrt, saveStorySubtitle };
