const admin = require("firebase-admin");
const fs = require("node:fs/promises");
const os = require("node:os");
const path = require("node:path");
const { execFile } = require("node:child_process");
const { promisify } = require("node:util");

const run = promisify(execFile);
const ffmpegPath = require("ffmpeg-static");
const ffprobePath = require("ffprobe-static").path;

async function assembleVoiceChunks(storyId, chunks) {
  if (!ffmpegPath || !ffprobePath) {
    throw new Error("FFmpeg tools are unavailable.");
  }

  if (!Array.isArray(chunks) || chunks.length === 0) {
    throw new Error("No voice chunks were provided.");
  }

  const ordered = [...chunks].sort(
    (a, b) => a.chunkIndex - b.chunkIndex
  );

  // Ensure every expected chunk is present and completed.
  ordered.forEach((chunk, index) => {
    if (
      chunk.chunkIndex !== index ||
      chunk.status !== "completed" ||
      !chunk.storagePath
    ) {
      throw new Error(`Voice chunk ${index} is missing or incomplete.`);
    }
  });

  const tempDir = await fs.mkdtemp(
    path.join(os.tmpdir(), "story-voice-")
  );

  try {
    const bucket = admin.storage().bucket();

    // Download chunks in the correct order.
    for (let i = 0; i < ordered.length; i++) {
      const localPath = path.join(
        tempDir,
        `chunk-${String(i).padStart(4, "0")}.mp3`
      );

      await bucket.file(ordered[i].storagePath).download({
        destination: localPath,
      });

      ordered[i].localPath = localPath;
    }

    const concatPath = path.join(tempDir, "concat.txt");
    const concatContents = ordered
      .map((chunk) => {
        const safePath = chunk.localPath.replace(/'/g, "'\\''");
        return `file '${safePath}'`;
      })
      .join("\n");

    await fs.writeFile(concatPath, concatContents, "utf8");

    const outputPath = path.join(tempDir, "final.mp3");

    await run(
      ffmpegPath,
      [
        "-hide_banner",
        "-loglevel", "error",
        "-f", "concat",
        "-safe", "0",
        "-i", concatPath,
        "-c", "copy",
        "-y", outputPath,
      ],
      { timeout: 10 * 60 * 1000 }
    );

    // Read actual duration from the assembled audio.
    const { stdout } = await run(
      ffprobePath,
      [
        "-v", "error",
        "-show_entries", "format=duration",
        "-of", "json",
        outputPath,
      ],
      { timeout: 60 * 1000 }
    );

    const probe = JSON.parse(stdout);
    const durationSeconds = Number(probe.format?.duration);

    if (!Number.isFinite(durationSeconds) || durationSeconds <= 0) {
      throw new Error("Could not determine final audio duration.");
    }

    const finalStoragePath =
      `stories/${storyId}/voice/final.mp3`;

    await bucket.upload(outputPath, {
      destination: finalStoragePath,
      resumable: false,
      metadata: {
        contentType: "audio/mpeg",
        cacheControl: "private, no-store",
      },
    });

    return {
      voicePath: finalStoragePath,
      voiceDurationSeconds: Math.round(durationSeconds),
      voiceChunkCount: ordered.length,
      voiceStatus: "completed",
    };
  } finally {
    await fs.rm(tempDir, { recursive: true, force: true });
  }
}

module.exports = { assembleVoiceChunks };
