const { generateVoiceChunks, splitScriptForVoice } = require("./voice_chunks");

module.exports = { generateVoiceChunks, splitScriptForVoice };
