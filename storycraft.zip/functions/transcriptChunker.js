function splitIntoChunks(text, count) {
  if (typeof text !== "string" || !text.trim()) {
    throw new Error("Transcript is empty.");
  }

  if (!Number.isInteger(count) || count < 1 || count > 18) {
    throw new Error("Chunk count must be between 1 and 18.");
  }

  const words = text.trim().split(/\s+/);
  const chunks = [];
  const chunkSize = Math.ceil(words.length / count);

  for (let i = 0; i < count; i++) {
    const start = i * chunkSize;
    const part = words.slice(start, start + chunkSize).join(" ");

    if (part) {
      chunks.push({
        index: chunks.length,
        sourceText: part,
      });
    }
  }

  return chunks;
}

module.exports = { splitIntoChunks };
