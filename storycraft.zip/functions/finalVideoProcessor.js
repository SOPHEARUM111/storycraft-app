const ffmpeg = require("fluent-ffmpeg");
const ffmpegPath = require("ffmpeg-static");
const path = require("path");
const fs = require("fs");

ffmpeg.setFfmpegPath(ffmpegPath);

function renderFinalVideo({
  videoPath,
  voicePath,
  subtitlePath,
  outputPath,
}) {
  return new Promise((resolve, reject) => {
    const fontsDir = path.join(
      __dirname,
      "assets",
      "fonts"
    );

    if (!fs.existsSync(path.join(
      fontsDir,
      "NotoSansKhmer-Regular.ttf"
    ))) {
      return reject(
        new Error("Noto Sans Khmer font file is missing.")
      );
    }

    // The temporary paths used here should not contain
    // colons, quotes, or other FFmpeg filter syntax characters.
    const subtitleFilter =
      `subtitles=${subtitlePath}:fontsdir=${fontsDir}`;

    ffmpeg()
      .input(videoPath)
      .input(voicePath)
      .outputOptions([
        "-map 0:v:0",
        "-map 1:a:0",
        "-c:v libx264",
        "-preset veryfast",
        "-crf 23",
        "-pix_fmt yuv420p",
        "-c:a aac",
        "-b:a 192k",
        "-shortest",
        "-movflags +faststart",
      ])
      .videoFilters([
        "scale=1080:1920:force_original_aspect_ratio=increase",
        "crop=1080:1920",
        subtitleFilter,
      ])
      .format("mp4")
      .on("start", (command) => {
        console.log("FFmpeg started:", command);
      })
      .on("end", () => {
        resolve(outputPath);
      })
      .on("error", (error) => {
        reject(error);
      })
      .save(outputPath);
  });
}

module.exports = { renderFinalVideo };
