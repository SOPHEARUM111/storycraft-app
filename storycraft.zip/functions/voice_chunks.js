const OpenAI = require("openai");
const { splitScriptForVoice } = require("./voice_splitter");

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

async function generateVoiceChunks(script, storyId) {
  const chunks = splitScriptForVoice(script, 3000);
  const bucket = require("firebase-admin").storage().bucket();

  const results = [];

  for (let i = 0; i < chunks.length; i++) {
    const response = await openai.audio.speech.create({
      model: "gpt-4o-mini-tts",
      voice: "alloy",
      input: chunks[i],
      instructions:
        "Narrate naturally and clearly. Keep a consistent pace and tone.",
      response_format: "mp3",
    });

    const audioBuffer = Buffer.from(
      await response.arrayBuffer()
    );

    const path =
      `stories/${storyId}/voice_chunks/chunk_${String(i).padStart(3, "0")}.mp3`;

    await bucket.file(path).save(audioBuffer, {
      resumable: false,
      metadata: {
        contentType: "audio/mpeg",
        cacheControl: "private, no-store",
      },
    });

    results.push({
      chunkIndex: i,
      storagePath: path,
      status: "completed",
      contentType: "audio/mpeg",
      characterCount: chunks[i].length,
      byteLength: audioBuffer.length,
    });
  }

  return results;
}

module.exports = { generateVoiceChunks, splitScriptForVoice };
