const admin = require("firebase-admin");
const { assembleVoiceChunks } = require("./voice_assembler");

if (!admin.apps.length) {
  admin.initializeApp();
}

// Call this only after every voice chunk has completed.
async function finalizeStoryVoice(storyId, chunks) {
  const result = await assembleVoiceChunks(storyId, chunks);

  const storyRef = admin.firestore()
    .collection("stories")
    .doc(storyId);

  await storyRef.update({
    voicePath: result.voicePath,
    voiceDurationSeconds: result.voiceDurationSeconds,
    voiceChunkCount: result.voiceChunkCount,
    voiceStatus: "completed",
    processingStep: "voice_completed",
    updatedAt: admin.firestore.FieldValue.serverTimestamp(),
  });

  return result;
}

module.exports = { assembleVoiceChunks, finalizeStoryVoice };
