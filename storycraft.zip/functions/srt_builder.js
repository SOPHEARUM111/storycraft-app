function formatSrtTime(seconds) {
  const ms = Math.round(seconds * 1000);
  const hours = Math.floor(ms / 3600000);
  const minutes = Math.floor((ms % 3600000) / 60000);
  const secs = Math.floor((ms % 60000) / 1000);
  const millis = ms % 1000;

  return (
    `${String(hours).padStart(2, "0")}:` +
    `${String(minutes).padStart(2, "0")}:` +
    `${String(secs).padStart(2, "0")},` +
    `${String(millis).padStart(3, "0")}`
  );
}

function buildSrt(segments) {
  if (!Array.isArray(segments) || segments.length === 0) {
    throw new Error("No subtitle segments provided.");
  }

  const ordered = [...segments].sort(
    (a, b) => a.start - b.start
  );

  const entries = ordered.map((segment, index) => {
    const { start, end, text } = segment;

    if (
      !Number.isFinite(start) ||
      !Number.isFinite(end) ||
      start < 0 ||
      end <= start ||
      typeof text !== "string" ||
      !text.trim()
    ) {
      throw new Error(`Invalid subtitle segment ${index}.`);
    }

    return [
      String(index + 1),
      `${formatSrtTime(start)} --> ${formatSrtTime(end)}`,
      text.trim(),
    ].join("\n");
  });

  return entries.join("\n\n") + "\n";
}

module.exports = { buildSrt, formatSrtTime };
