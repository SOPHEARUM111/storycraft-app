const fsPromises = require("fs/promises");
const os = require("os");
const path = require("path");
const { getStorage } = require("firebase-admin/storage");
const { FieldValue } = require("firebase-admin/firestore");
const { renderFinalVideo } = require("./finalVideoProcessor");

async function runRenderVideo(story) {
  const data = typeof story.data === "function" ? story.data() : story.data;
  const uid = data.userId;
  const storyId = story.id;

  if (
    !data.sourceVideoPath ||
    !data.voicePath ||
    !data.subtitlePath
  ) {
    throw new Error(
      "Missing sourceVideoPath, voicePath, or subtitlePath."
    );
  }

  const bucket = getStorage().bucket();
  const tempDir = await fsPromises.mkdtemp(
    path.join(os.tmpdir(), "story-render-")
  );

  const videoPath = path.join(tempDir, "source.mp4");
  const voicePath = path.join(tempDir, "voice.mp3");
  const subtitlePath = path.join(tempDir, "subtitle.ass");
  const outputPath = path.join(tempDir, "final.mp4");

  const downloadFromStorage = async (storagePath, localPath) => {
    await bucket.file(storagePath).download({
      destination: localPath,
    });
  };

  try {
    await story.ref.update({
      status: "rendering_video",
      processingStep: "rendering_video",
      processingProgress: 92,
      errorMessage: null,
      updatedAt: FieldValue.serverTimestamp(),
    });

    await Promise.all([
      downloadFromStorage(data.sourceVideoPath, videoPath),
      downloadFromStorage(data.voicePath, voicePath),
      downloadFromStorage(data.subtitlePath, subtitlePath),
    ]);

    await renderFinalVideo({
      videoPath,
      voicePath,
      subtitlePath,
      outputPath,
    });

    const finalVideoPath =
      `users/${uid}/stories/${storyId}/final.mp4`;

    await bucket.upload(outputPath, {
      destination: finalVideoPath,
      metadata: {
        contentType: "video/mp4",
        metadata: {
          storyId,
          userId: uid,
        },
      },
    });

    await story.ref.update({
      finalVideoPath,
      status: "completed",
      processingStep: "completed",
      processingProgress: 100,
      errorMessage: null,
      updatedAt: FieldValue.serverTimestamp(),
    });

    return { finalVideoPath };
  } catch (error) {
    await story.ref.update({
      status: "error",
      processingStep: "rendering_video",
      errorMessage: String(error.message || error).slice(0, 1000),
      updatedAt: FieldValue.serverTimestamp(),
    });

    throw error;
  } finally {
    await fsPromises.rm(tempDir, {
      recursive: true,
      force: true,
    });
  }
}

module.exports = { runRenderVideo };
