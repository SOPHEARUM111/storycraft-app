const admin = require("firebase-admin");

if (!admin.apps.length) {
  admin.initializeApp();
}
const db = admin.firestore();

const JOBS = [
  "extract_audio",
  "transcribe",
  "generate_recap",
  "generate_voice",
  "generate_subtitle",
  "render_video",
];

async function createNextJob(story, currentType) {
  const currentIndex = JOBS.indexOf(currentType);

  if (currentIndex === -1) {
    throw new Error(`Unknown job type: ${currentType}`);
  }

  const nextType = JOBS[currentIndex + 1];

  // No more jobs - Terminal condition!
  if (!nextType) {
    await db.collection("stories").doc(story.id).update({
      status: "completed",
      processingStep: "completed",
      processingProgress: 100,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    return null;
  }

  const jobRef = db.collection("storyJobs").doc();

  await jobRef.set({
    storyId: story.id,
    userId: story.data ? story.data.userId : "USER_ID",
    type: nextType,
    status: "queued",
    attempts: 0,
    errorMessage: null,
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
    updatedAt: admin.firestore.FieldValue.serverTimestamp(),
  });

  return jobRef.id;
}

async function markJobProcessing(jobRef) {
  const now = admin.firestore.FieldValue.serverTimestamp();

  await jobRef.update({
    status: "processing",
    startedAt: now,
    heartbeatAt: now,
    updatedAt: now,
    errorMessage: null,
  });
}

async function updateJobHeartbeat(jobRef, step) {
  const now = admin.firestore.FieldValue.serverTimestamp();

  await jobRef.update({
    processingStep: step,
    heartbeatAt: now,
    updatedAt: now,
  });
}

async function markJobCompleted(jobRef) {
  const snap = await jobRef.get();

  if (!snap.exists) {
    throw new Error("Job not found.");
  }

  const data = snap.data();
  const startedAtMs = data.startedAt?.toMillis?.();
  const completedAtMs = Date.now();

  const durationMs =
    typeof startedAtMs === "number"
      ? Math.max(0, completedAtMs - startedAtMs)
      : null;

  const update = {
    status: "completed",
    completedAt: admin.firestore.Timestamp.fromMillis(completedAtMs),
    heartbeatAt: admin.firestore.FieldValue.serverTimestamp(),
    updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    errorMessage: null,
  };

  if (durationMs !== null) {
    update.durationMs = durationMs;
  }

  await jobRef.update(update);
}

async function markJobError(jobRef, error) {
  const now = admin.firestore.FieldValue.serverTimestamp();

  await jobRef.update({
    status: "error",
    errorMessage: String(error.message || error).slice(0, 1000),
    heartbeatAt: now,
    updatedAt: now,
  });
}

module.exports = {
  JOBS,
  createNextJob,
  markJobProcessing,
  updateJobHeartbeat,
  markJobCompleted,
  markJobError,
};
