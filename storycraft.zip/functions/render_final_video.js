const admin = require("firebase-admin");
const fs = require("node:fs/promises");
const os = require("node:os");
const path = require("node:path");
const { execFile } = require("node:child_process");
const { promisify } = require("node:util");
const ffmpegPath = require("ffmpeg-static");

if (!admin.apps.length) {
  admin.initializeApp();
}

const run = promisify(execFile);

async function renderFinalVideo(storyId) {
  if (!ffmpegPath) {
    throw new Error("FFmpeg binary is unavailable.");
  }

  const db = admin.firestore();
  const storyRef = db.collection("stories").doc(storyId);
  const snapshot = await storyRef.get();

  if (!snapshot.exists) {
    throw new Error("Story not found.");
  }

  const story = snapshot.data();

  const { sourceVideoPath, voicePath, subtitlePath } = story;

  if (!sourceVideoPath || !voicePath || !subtitlePath) {
    throw new Error("Video, narration, or subtitle is missing.");
  }

  const bucket = admin.storage().bucket();
  const tempDir = await fs.mkdtemp(
    path.join(os.tmpdir(), "story-render-")
  );

  try {
    const inputVideo = path.join(tempDir, "input.mp4");
    const narration = path.join(tempDir, "voice.mp3");
    const subtitle = path.join(tempDir, "subtitle.srt");
    const outputVideo = path.join(tempDir, "final.mp4");

    await Promise.all([
      bucket.file(sourceVideoPath).download({
        destination: inputVideo,
      }),
      bucket.file(voicePath).download({
        destination: narration,
      }),
      bucket.file(subtitlePath).download({
        destination: subtitle,
      }),
    ]);

    // This simple version burns subtitles into the video.
    // The rendering environment must support the subtitles filter
    // and have a font that correctly displays Khmer.
    const subtitleFilter = `subtitles=${subtitle}`;

    await run(
      ffmpegPath,
      [
        "-hide_banner",
        "-loglevel", "error",
        "-i", inputVideo,
        "-i", narration,
        "-vf", subtitleFilter,
        "-map", "0:v:0",
        "-map", "1:a:0",
        "-c:v", "libx264",
        "-preset", "veryfast",
        "-crf", "23",
        "-c:a", "aac",
        "-b:a", "192k",
        "-shortest",
        "-movflags", "+faststart",
        "-y", outputVideo,
      ],
      { timeout: 60 * 60 * 1000 }
    );

    const stat = await fs.stat(outputVideo);

    if (stat.size === 0) {
      throw new Error("Rendered video is empty.");
    }

    const finalVideoPath = `stories/${storyId}/final/final.mp4`;

    await bucket.upload(outputVideo, {
      destination: finalVideoPath,
      resumable: false,
      metadata: {
        contentType: "video/mp4",
        cacheControl: "private, no-store",
      },
    });

    await storyRef.update({
      finalVideoPath,
      videoStatus: "completed",
      processingStep: "video_completed",
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    return { finalVideoPath, videoStatus: "completed" };
  } finally {
    await fs.rm(tempDir, { recursive: true, force: true });
  }
}

module.exports = { renderFinalVideo };
