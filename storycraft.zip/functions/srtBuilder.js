const { buildSrt, formatSrtTime } = require("./srt_builder");

module.exports = { buildSrt, formatSrtTime };
