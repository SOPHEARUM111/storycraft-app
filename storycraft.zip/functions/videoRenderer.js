const { renderFinalVideo } = require("./render_final_video");

module.exports = { renderFinalVideo };
