function formatAssTime(seconds) {
  const totalCentiseconds = Math.max(
    0,
    Math.round(seconds * 100)
  );

  const centiseconds =
    totalCentiseconds % 100;

  const totalSeconds =
    Math.floor(totalCentiseconds / 100);

  const secondsPart =
    totalSeconds % 60;

  const totalMinutes =
    Math.floor(totalSeconds / 60);

  const minutesPart =
    totalMinutes % 60;

  const hoursPart =
    Math.floor(totalMinutes / 60);

  return (
    `${hoursPart}:` +
    `${String(minutesPart).padStart(2, "0")}:` +
    `${String(secondsPart).padStart(2, "0")}.` +
    `${String(centiseconds).padStart(2, "0")}`
  );
}

function escapeAssText(text) {
  return String(text)
    .replace(/\\/g, "\\\\")
    .replace(/\{/g, "\\{")
    .replace(/\}/g, "\\}");
}

function splitSentences(text) {
  return text
    .split(/(?<=[។!?])\s+/)
    .map((item) => item.trim())
    .filter(Boolean);
}

function createAssSubtitle(
  script,
  secondsPerSentence = 4
) {
  const sentences = splitSentences(script);

  const header = `[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Khmer,Noto Sans Khmer,58,&H00FFFFFF,&H00FFFFFF,&H00000000,&H80000000,0,0,0,0,100,100,0,0,1,3,1,2,80,80,180,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
`;

  const events = [];

  sentences.forEach((sentence, index) => {
    const start =
      index * secondsPerSentence;

    const end =
      start + secondsPerSentence;

    events.push(
      `Dialogue: 0,` +
      `${formatAssTime(start)},` +
      `${formatAssTime(end)},` +
      `Khmer,,0,0,0,,` +
      `${escapeAssText(sentence)}`
    );
  });

  return header + events.join("\n");
}

const { buildSrt, formatSrtTime } = require("./srt_builder");

module.exports = {
  createAssSubtitle,
  buildSrt,
  formatSrtTime,
};
