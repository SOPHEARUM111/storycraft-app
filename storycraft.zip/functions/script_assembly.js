const { assembleScriptChunks, normalizeForComparison } = require("./scriptAssembler");

module.exports = {
  assembleScriptChunks,
  normalizeForComparison,
};
