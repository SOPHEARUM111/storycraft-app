const { splitScriptForVoice } = require("./voice_splitter");

module.exports = { splitScriptForVoice };
