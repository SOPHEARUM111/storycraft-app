# Storycraft Firebase Integration Status

## Changes made in this prepared source bundle

- Added Firebase Android dependencies for Authentication, Firestore, Storage, and Cloud Functions.
- Added email/password authentication and Google Credential Manager sign-in UI.
- Replaced the sample story list with a Firestore listener scoped to the signed-in user's `userId`.
- Changed Create Story from generating a fake completed item to selecting and uploading a real video, calling `completeStoryUpload`, then calling `startStoryProcessing` in `asia-southeast1`.
- Added a server-side `completeStoryUpload` callable that checks ownership and Storage object metadata before setting backend-managed fields.
- Tightened Firestore client rules and added private Storage rules for source-video uploads.
- Added `firebase.json` and a GitHub Actions workflow for cloud debug-APK builds.
- Replaced the invalid `gpt-6-luna` model ID used by the background worker with `gpt-4o-mini`.
- Connected the Story Detail retry action to the existing `retryStoryJob` callable.

## Required setup in the user's Firebase project

1. Create/select a Firebase project and register Android package `com.example.aistorystudio`.
2. Download the project's `google-services.json` into `app/google-services.json`.
3. Enable Firebase Authentication Email/Password and Google providers.
4. Configure the Google OAuth web client and add the SHA-1/SHA-256 fingerprints for the APK signing certificate(s). Google sign-in will not work until this is correct.
5. Create Firestore and Storage in the same Firebase project and review `firestore.rules` and `storage.rules` before deploying.
6. Set the server-only secret `OPENAI_API_KEY` with Firebase CLI; never put it in Android source or the APK.
7. Deploy Functions and rules, then test using a small, non-sensitive video.

## Cloud APK build from an Android phone

The workflow `.github/workflows/android-apk.yml` expects a GitHub Actions repository secret named `FIREBASE_GOOGLE_SERVICES_JSON_BASE64`. Its value is the Base64 encoding of the correct `google-services.json`. Run the **Build Android APK** workflow and download the `ai-story-studio-debug-apk` artifact after a successful run.

## Important validation status

- JavaScript syntax checks passed for the included Cloud Functions source files.
- `firebase.json`, the Gradle version catalog, and Android manifest passed basic parse checks.
- Kotlin parser checks found no syntax-level errors in the edited Kotlin files, but a real Android Gradle build could not be run in this environment because the supplied archive has no Gradle Wrapper and no Firebase project configuration, and Gradle/Android dependencies could not be downloaded here.
- This bundle has **not** been built into an APK and has **not** been tested against a live Firebase project.
- The backend still needs an end-to-end test for large movie inputs. In particular, the current transcription function sends one extracted audio file to the transcription API; long movies may exceed provider file-size limits or Cloud Functions execution limits. Chunked transcription and chunked recap generation must be validated/finished before claiming reliable support for long movies or 1–90 minute outputs.
- The screens for final video playback/publishing still contain preview/mock behavior and should be connected to real generated media before public release.
