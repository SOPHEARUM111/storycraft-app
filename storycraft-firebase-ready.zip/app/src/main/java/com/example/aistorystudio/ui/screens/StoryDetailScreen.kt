package com.example.aistorystudio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aistorystudio.data.model.Story
import com.example.aistorystudio.data.model.StoryStatus
import com.google.firebase.functions.FirebaseFunctions
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoryDetailScreen(
    story: Story,
    onBackClick: () -> Unit,
    onPublishClick: (() -> Unit)? = null
) {
    val clipboardManager = LocalClipboardManager.current
    var scriptText by remember { mutableStateOf(story.script) }
    var isEditing by remember { mutableStateOf(false) }
    var snackbarMessage by remember { mutableStateOf<String?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var currentPositionSec by remember { mutableFloatStateOf(0f) }
    val totalDurationSec = 60f
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            kotlinx.coroutines.delay(100)
            if (currentPositionSec >= totalDurationSec) {
                currentPositionSec = 0f
            } else {
                currentPositionSec += 0.1f
            }
        }
    }

    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            snackbarMessage = null
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = story.title,
                        maxLines = 1,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { snackbarMessage = "បានចម្លង Caption & Hashtags សម្រាប់ Share ទៅកាន់ TikTok / Shorts រួចរាល់!" }) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Share"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 📊 Real-Time Video Status Component
            BuildVideoStatus(
                story = story,
                onRetryClick = {
                    coroutineScope.launch {
                        try {
                            FirebaseFunctions.getInstance("asia-southeast1")
                                .getHttpsCallable("retryStoryJob")
                                .call(mapOf("storyId" to story.id))
                                .await()
                            snackbarMessage = "បានស្នើសុំដំណើរការរឿងឡើងវិញ។"
                        } catch (e: Exception) {
                            snackbarMessage = e.localizedMessage ?: "មិនអាច Retry បានទេ។ សូមពិនិត្យស្ថានភាពរឿង។"
                        }
                    }
                }
            )

            // Video 9:16 Player & Controls
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161622)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Video 9:16 Canvas Area
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(240.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF0F0E17)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Videocam else Icons.Default.PlayCircleFilled,
                                contentDescription = if (isPlaying) "Playing" else "Paused",
                                tint = if (isPlaying) Color(0xFF10B981) else MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (isPlaying) "▶️ កំពុងចាក់ 9:16 Shorts (1080×1920)" else "9:16 HD Shorts Ready",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "Subtitle: Noto Sans Khmer • Voice: Khmer AI",
                                color = Color.White.copy(alpha = 0.6f),
                                fontSize = 11.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // ────────────── Progress Bar ──────────────
                    val currentMins = (currentPositionSec / 60).toInt()
                    val currentSecs = (currentPositionSec % 60).toInt()
                    val totalMins = (totalDurationSec / 60).toInt()
                    val totalSecs = (totalDurationSec % 60).toInt()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = String.format("%02d:%02d", currentMins, currentSecs),
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Slider(
                            value = currentPositionSec,
                            onValueChange = { currentPositionSec = it },
                            valueRange = 0f..totalDurationSec,
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 8.dp)
                                .testTag("video_progress_slider")
                        )
                        Text(
                            text = String.format("%02d:%02d", totalMins, totalSecs),
                            color = Color.White.copy(alpha = 0.5f),
                            fontSize = 12.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // ──────── Control Row: [ Restart ] [ Play/Pause ] [ 💾 Save ] [ 📤 Share ] ────────
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // 🔄 RESTART BUTTON (Resets position to zero)
                        IconButton(
                            onClick = {
                                currentPositionSec = 0f
                                isPlaying = true
                            },
                            modifier = Modifier.testTag("restart_video_button"),
                            colors = IconButtonDefaults.iconButtonColors(
                                containerColor = Color.White.copy(alpha = 0.12f)
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.Replay,
                                contentDescription = "Restart video from beginning",
                                tint = Color.White
                            )
                        }

                        // ▶️ / ⏸️ PLAY / PAUSE BUTTON
                        IconButton(
                            onClick = { isPlaying = !isPlaying },
                            modifier = Modifier.testTag("play_pause_video_button"),
                            colors = IconButtonDefaults.iconButtonColors(
                                containerColor = MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isPlaying) "Pause" else "Play",
                                tint = MaterialTheme.colorScheme.onPrimary
                            )
                        }

                        // 💾 SAVE TO GALLERY BUTTON
                        ElevatedButton(
                            onClick = { snackbarMessage = "បានរក្សាទុក Video ទៅ Gallery រួចហើយ ✅ (Movies / Story Recap)" },
                            modifier = Modifier.testTag("save_to_gallery_button"),
                            colors = ButtonDefaults.elevatedButtonColors(
                                containerColor = Color(0xFF4F46E5),
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Download,
                                contentDescription = "Save",
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Save", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }

                        // 📤 SHARE BUTTON
                        OutlinedButton(
                            onClick = { snackbarMessage = "បានចម្លង Caption & Hashtags សម្រាប់ Share ទៅកាន់ TikTok / Shorts រួចរាល់!" },
                            modifier = Modifier.testTag("share_video_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "Share",
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Share", fontSize = 13.sp)
                        }
                    }
                }
            }

            // Share buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { snackbarMessage = "បានចម្លង Caption & Hashtags សម្រាប់ TikTok រួចរាល់!" },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE11D48)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("TikTok", fontWeight = FontWeight.Bold)
                }
                Button(
                    onClick = { snackbarMessage = "បានចម្លង Caption & Hashtags សម្រាប់ Reels រួចរាល់!" },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9333EA)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Reels", fontWeight = FontWeight.Bold)
                }
                Button(
                    onClick = { snackbarMessage = "បានចម្លង Caption & Hashtags សម្រាប់ Shorts រួចរាល់!" },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Shorts", fontWeight = FontWeight.Bold)
                }
            }

            // Script Section
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "📝 អត្ថបទសម្រាយរឿង (Script)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        IconButton(onClick = { isEditing = !isEditing }) {
                            Icon(
                                imageVector = if (isEditing) Icons.Default.Check else Icons.Default.Edit,
                                contentDescription = "Edit"
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (isEditing) {
                        OutlinedTextField(
                            value = scriptText,
                            onValueChange = { scriptText = it },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 4
                        )
                    } else {
                        Text(
                            text = scriptText.ifEmpty { "មិនទាន់មាន Script នៅឡើយទេ..." },
                            fontSize = 14.sp,
                            lineHeight = 22.sp
                        )
                    }
                }
            }

            // 🚀 Social Distribution Kit Section
            val effectiveSocialTitle = story.socialTitle.ifEmpty { "អាថ៌កំបាំងដែលមិនធ្លាប់ដឹង! 😱 សម្រាយរឿង ${story.title} #Shorts" }
            val effectiveSocialDesc = story.socialDescription.ifEmpty { "រឿងនេះនិយាយអំពីដំណើរផ្សងព្រេងដ៏រំភើបរបស់បុរសម្នាក់..." }

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "🚀 Social Distribution Kit",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        SuggestionChip(
                            onClick = {},
                            label = { Text("● ${story.socialStatus.uppercase()}", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = SuggestionChipDefaults.suggestionChipColors(
                                containerColor = Color(0xFF10B981).copy(alpha = 0.2f),
                                labelColor = Color(0xFF10B981)
                            )
                        )
                    }

                    // 🎬 socialTitle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "🎬 Title", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                        TextButton(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(effectiveSocialTitle))
                                snackbarMessage = "📋 បានចម្លង Title រួចរាល់!"
                            },
                            modifier = Modifier.testTag("copy_title_button")
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy Title", modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Copy Title", fontSize = 12.sp)
                        }
                    }
                    Text(
                        text = effectiveSocialTitle,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )

                    // 📝 socialDescription
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "📝 Description", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                        TextButton(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(effectiveSocialDesc))
                                snackbarMessage = "📋 បានចម្លង Description រួចរាល់!"
                            },
                            modifier = Modifier.testTag("copy_description_button")
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy Description", modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Copy Description", fontSize = 12.sp)
                        }
                    }
                    Text(
                        text = effectiveSocialDesc,
                        fontSize = 13.sp,
                        color = Color.White.copy(alpha = 0.8f)
                    )

                    // #️⃣ hashtags
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "#️⃣ Hashtags", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                        TextButton(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(story.hashtags))
                                snackbarMessage = "📋 បានចម្លង Hashtags រួចរាល់!"
                            },
                            modifier = Modifier.testTag("copy_hashtags_button")
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy Hashtags", modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Copy Hashtags", fontSize = 12.sp)
                        }
                    }
                    Text(
                        text = story.hashtags,
                        fontSize = 12.sp,
                        color = Color(0xFF38BDF8)
                    )

                    // 🏷️ tags
                    Text(text = "🏷️ Tags (SEO):", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    Text(
                        text = story.tags,
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.6f)
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    // 📋 Copy All Button
                    Button(
                        onClick = {
                            val fullBundle = "$effectiveSocialTitle\n\n$effectiveSocialDesc\n\n${story.hashtags}"
                            clipboardManager.setText(AnnotatedString(fullBundle))
                            snackbarMessage = "📋 បានចម្លងកញ្ចប់ Caption & Hashtags ទាំងអស់ (Copy All) រួចរាល់! 🎉"
                        },
                        modifier = Modifier.fillMaxWidth().testTag("copy_all_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy All", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("📋 Copy All (Title + Description + Hashtags)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    val canPublish = story.status == StoryStatus.COMPLETED

                    if (canPublish && onPublishClick != null) {
                        Button(
                            onClick = onPublishClick,
                            modifier = Modifier.fillMaxWidth().testTag("publish_video_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Publish, contentDescription = "Publish", modifier = Modifier.size(18.dp), tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("🚀 Publish Video", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

/**
 * 📊 buildVideoStatus(story) Component
 */
@Composable
fun BuildVideoStatus(
    story: Story,
    modifier: Modifier = Modifier,
    onRetryClick: (() -> Unit)? = null
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = when (story.status) {
                StoryStatus.COMPLETED -> Color(0xFF064E3B).copy(alpha = 0.6f)
                StoryStatus.ERROR -> Color(0xFF7F1D1D).copy(alpha = 0.6f)
                else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
            }
        ),
        modifier = modifier.fillMaxWidth().testTag("video_status_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            when {
                story.status == StoryStatus.COMPLETED -> {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Completed",
                            tint = Color(0xFF10B981),
                            modifier = Modifier.size(32.dp)
                        )
                        Column {
                            Text(
                                text = "វីដេអូរួចរាល់ 🎉",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color.White
                            )
                            Text(
                                text = "អ្នកអាចមើល និងចែករំលែកបាន",
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.7f)
                            )
                        }
                    }
                }
                story.status == StoryStatus.ERROR -> {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Error,
                                contentDescription = "Error",
                                tint = Color(0xFFEF4444),
                                modifier = Modifier.size(32.dp)
                            )
                            Column {
                                Text(
                                    text = "បង្កើតវីដេអូមិនបានសម្រេច",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = Color.White
                                )
                                Text(
                                    text = story.errorMessage?.ifBlank { "សូមសាកល្បងម្ដងទៀត" } ?: "សូមសាកល្បងម្ដងទៀត",
                                    fontSize = 12.sp,
                                    color = Color(0xFFFCA5A5)
                                )
                            }
                        }

                        if (onRetryClick != null) {
                            BuildRetryButton(
                                story = story,
                                onRetryClick = onRetryClick
                            )
                        }
                    }
                }
                else -> {
                    val progressValue = when (story.status) {
                        StoryStatus.UPLOADING -> 20f
                        StoryStatus.TRANSCRIBING -> 45f
                        StoryStatus.GENERATING_RECAP -> 65f
                        StoryStatus.GENERATING_VOICE -> 80f
                        StoryStatus.GENERATING_SUBTITLE -> 90f
                        StoryStatus.RENDERING_VIDEO -> 95f
                        else -> 30f
                    }
                    Text(
                        text = "កំពុងដំណើរការ៖ ${story.status.name.lowercase().replace('_', ' ')}",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp,
                        color = Color.White
                    )
                    LinearProgressIndicator(
                        progress = { (progressValue / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = Color.White.copy(alpha = 0.15f)
                    )
                    Text(
                        text = "${progressValue.toInt()}%",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

/**
 * 🔄 buildRetryButton(context, storyId, story) Component
 */
@Composable
fun BuildRetryButton(
    story: Story,
    onRetryClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (story.status != StoryStatus.ERROR) return

    Button(
        onClick = onRetryClick,
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
        modifier = modifier.fillMaxWidth().testTag("retry_story_button"),
        shape = RoundedCornerShape(10.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Refresh,
            contentDescription = "Retry",
            modifier = Modifier.size(16.dp),
            tint = Color.White
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = "សាកល្បងម្ដងទៀត",
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            color = Color.White
        )
    }
}

