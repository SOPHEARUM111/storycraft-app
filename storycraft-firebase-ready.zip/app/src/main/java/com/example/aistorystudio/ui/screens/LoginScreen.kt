package com.example.aistorystudio.ui.screens

import android.util.Log
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialException
import com.example.aistorystudio.R
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

@Composable
fun LoginScreen() {
    val context = LocalContext.current
    val auth = remember { FirebaseAuth.getInstance() }
    val scope = rememberCoroutineScope()
    val snackbarHost = remember { SnackbarHostState() }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var createAccount by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }

    Scaffold(snackbarHost = { SnackbarHost(snackbarHost) }) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Default.Movie, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(12.dp))
            Text("AI សម្រាយរឿង", fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text("ចូលគណនី ដើម្បីរក្សាទុករឿងរបស់អ្នក", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(24.dp))
            OutlinedTextField(
                value = email,
                onValueChange = { email = it.trim() },
                label = { Text("Email") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Password") },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    if (email.isBlank() || password.length < 6) {
                        scope.launch { snackbarHost.showSnackbar("សូមបញ្ចូល Email និង Password យ៉ាងតិច 6 តួអក្សរ។") }
                        return@Button
                    }
                    scope.launch {
                        loading = true
                        try {
                            if (createAccount) auth.createUserWithEmailAndPassword(email, password).await()
                            else auth.signInWithEmailAndPassword(email, password).await()
                        } catch (e: Exception) {
                            snackbarHost.showSnackbar(e.localizedMessage ?: "មិនអាចចូលគណនីបានទេ។")
                        } finally {
                            loading = false
                        }
                    }
                },
                enabled = !loading,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                if (loading) CircularProgressIndicator()
                else Text(if (createAccount) "បង្កើតគណនី" else "ចូលគណនី")
            }
            OutlinedButton(
                onClick = { createAccount = !createAccount },
                enabled = !loading,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (createAccount) "មានគណនីរួចហើយ? ចូលគណនី" else "មិនទាន់មានគណនី? បង្កើតថ្មី") }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(
                onClick = {
                    scope.launch {
                        loading = true
                        try {
                            val resourceId = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
                            if (resourceId == 0) error("Firebase Google Sign-In មិនទាន់កំណត់ទេ។ សូមបន្ថែម google-services.json ដែលមាន Web OAuth client ID។")
                            val serverClientId = context.getString(resourceId)
                            val googleOption = GetGoogleIdOption.Builder()
                                .setFilterByAuthorizedAccounts(false)
                                .setServerClientId(serverClientId)
                                .setAutoSelectEnabled(false)
                                .build()
                            val request = GetCredentialRequest.Builder().addCredentialOption(googleOption).build()
                            val credentialManager = CredentialManager.create(context)
                            val result = credentialManager.getCredential(context, request)
                            val googleCredential = GoogleIdTokenCredential.createFrom(result.credential.data)
                            val firebaseCredential = GoogleAuthProvider.getCredential(googleCredential.idToken, null)
                            auth.signInWithCredential(firebaseCredential).await()
                        } catch (e: GetCredentialException) {
                            snackbarHost.showSnackbar(e.localizedMessage ?: "Google Sign-In ត្រូវបានបោះបង់ ឬបរាជ័យ។")
                        } catch (e: Exception) {
                            Log.e("LoginScreen", "Google sign-in failed", e)
                            snackbarHost.showSnackbar(e.localizedMessage ?: "Google Sign-In បរាជ័យ។ សូមពិនិត្យ Firebase OAuth setup។")
                        } finally {
                            loading = false
                        }
                    }
                },
                enabled = !loading,
                modifier = Modifier.fillMaxWidth()
            ) { Text("បន្តជាមួយ Google") }
        }
    }
}
