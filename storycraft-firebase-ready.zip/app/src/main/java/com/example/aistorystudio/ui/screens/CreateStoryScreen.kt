package com.example.aistorystudio.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import android.net.Uri
import com.example.aistorystudio.data.FirebaseStoryRepository
import kotlinx.coroutines.launch
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aistorystudio.data.model.Story

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateStoryScreen(
    onBackClick: () -> Unit,
    onStoryCreated: (Story) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var selectedTone by remember { mutableStateOf("Dramatic (រំភើបញាប់ញ័រ) 🔥") }
    var selectedDurationMinutes by remember { mutableIntStateOf(15) }
    var selectedVideoUri by remember { mutableStateOf<Uri?>(null) }
    var isSubmitting by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        selectedVideoUri = uri
    }

    val tones = listOf(
        "Dramatic (រំភើបញាប់ញ័រ) 🔥",
        "Funny (កំប្លែងសើចសប្បាយ) 😂",
        "Mystery (អាថ៌កំបាំងភ័យរន្ធត់) 👻"
    )



    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "បង្កើតសម្រាយរឿងថ្មី 🎬",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier.testTag("back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Text(
                text = "ចំណងជើងរឿង ឬឈ្មោះភាពយន្ត",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                placeholder = { Text("ឧទាហរណ៍៖ សង្រ្គាមលំហអាកាស ២០២៦...") },
                leadingIcon = { Icon(Icons.Default.Movie, contentDescription = null) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("story_title_input"),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Text(
                text = "រចនាបទសំឡេងសម្រាយ (Tone of Voice)",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )

            tones.forEach { tone ->
                Card(
                    onClick = { selectedTone = tone },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (selectedTone == tone)
                            MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = tone,
                        modifier = Modifier.padding(16.dp),
                        fontWeight = if (selectedTone == tone) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }

            Text(
                text = "រយៈពេលសម្រាយគោលដៅ: $selectedDurationMinutes នាទី (1–90 នាទី)",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            Slider(
                value = selectedDurationMinutes.toFloat(),
                onValueChange = { selectedDurationMinutes = it.toInt().coerceIn(1, 90) },
                valueRange = 1f..90f,
                steps = 88,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedButton(
                onClick = { videoPicker.launch(arrayOf("video/*")) },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Movie, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(selectedVideoUri?.lastPathSegment?.substringAfterLast('/') ?: "ជ្រើសរើសវីដេអូប្រភព")
            }

            Text(
                text = "វីដេអូត្រូវបានផ្ទុកទៅ Firebase Storage ហើយ Cloud Functions នឹងចាប់ផ្ដើមដំណើរការ AI។",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = {
                    val videoUri = selectedVideoUri
                    if (title.isBlank() || videoUri == null) {
                        scope.launch {
                            snackbarHostState.showSnackbar(
                                if (title.isBlank()) "សូមបញ្ចូលចំណងជើងរឿង។" else "សូមជ្រើសរើសវីដេអូជាមុនសិន។"
                            )
                        }
                    } else {
                        scope.launch {
                            isSubmitting = true
                            try {
                                val newStory = FirebaseStoryRepository.createStoryFromVideo(
                                    context = context,
                                    videoUri = videoUri,
                                    title = title.trim(),
                                    tone = selectedTone,
                                    targetMinutes = selectedDurationMinutes
                                )
                                onStoryCreated(newStory)
                            } catch (e: Exception) {
                                snackbarHostState.showSnackbar(e.localizedMessage ?: "មិនអាចបង្កើតរឿងបានទេ។ សូមពិនិត្យ Firebase និង Cloud Functions។")
                            } finally {
                                isSubmitting = false
                            }
                        }
                    }
                },
                enabled = title.isNotBlank() && selectedVideoUri != null && !isSubmitting,
                modifier = Modifier.fillMaxWidth().height(52.dp).testTag("submit_create_story_btn"),
                shape = RoundedCornerShape(12.dp)
            ) {
                if (isSubmitting) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("កំពុង Upload និងចាប់ផ្ដើម AI...")
                } else {
                    Icon(Icons.Default.AutoAwesome, contentDescription = "Movie Creation")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Upload និងចាប់ផ្ដើម AI សម្រាយរឿង", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }

        }
    }
}
