package com.example.aistorystudio.data

import android.content.Context
import android.net.Uri
import com.example.aistorystudio.data.model.Story
import com.example.aistorystudio.data.model.StoryStatus
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageMetadata
import kotlinx.coroutines.tasks.await

/** Firebase integration. OpenAI credentials are never stored in the Android app. */
object FirebaseStoryRepository {
    private val auth: FirebaseAuth get() = FirebaseAuth.getInstance()
    private val db: FirebaseFirestore get() = FirebaseFirestore.getInstance()
    private val storage: FirebaseStorage get() = FirebaseStorage.getInstance()
    private val functions: FirebaseFunctions get() = FirebaseFunctions.getInstance("asia-southeast1")

    fun observeStories(
        onStories: (List<Story>) -> Unit,
        onError: (Exception) -> Unit
    ): ListenerRegistration? {
        val uid = auth.currentUser?.uid ?: return null
        return db.collection("stories")
            .whereEqualTo("userId", uid)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    onError(error)
                    return@addSnapshotListener
                }
                onStories(snapshot?.documents.orEmpty().mapNotNull { doc ->
                    val title = doc.getString("title") ?: return@mapNotNull null
                    val statusKey = doc.getString("status") ?: "queued"
                    val status = StoryStatus.entries.firstOrNull { it.key == statusKey }
                        ?: when (statusKey) {
                            "uploaded", "draft" -> StoryStatus.QUEUED
                            else -> StoryStatus.PROCESSING
                        }
                    Story(
                        id = doc.id,
                        userId = doc.getString("userId") ?: uid,
                        title = title,
                        sourceVideoPath = doc.getString("sourceVideoPath") ?: "",
                        sourceAudioPath = doc.getString("sourceAudioPath"),
                        status = status,
                        processingStep = doc.getString("processingStep") ?: statusKey,
                        processingProgress = (doc.getLong("processingProgress") ?: 0L).toInt(),
                        transcript = doc.getString("transcript") ?: "",
                        script = doc.getString("script") ?: "",
                        audioPath = doc.getString("voicePath"),
                        subtitlePath = doc.getString("subtitlePath"),
                        finalVideoPath = doc.getString("finalVideoPath"),
                        errorMessage = doc.getString("errorMessage"),
                        socialTitle = doc.getString("socialTitle") ?: "",
                        socialDescription = doc.getString("socialDescription") ?: "",
                        hashtags = doc.getString("hashtags") ?: "",
                        tags = doc.getString("tags") ?: "",
                        tone = doc.getString("tone") ?: "Dramatic",
                        duration = "${doc.getLong("targetMinutes") ?: 1L} នាទី",
                        createdAt = doc.getTimestamp("createdAt")?.toDate()?.toString() ?: ""
                    )
                }.sortedByDescending { it.createdAt })
            }
    }

    suspend fun createStoryFromVideo(
        context: Context,
        videoUri: Uri,
        title: String,
        tone: String,
        targetMinutes: Int
    ): Story {
        val user = auth.currentUser ?: error("សូមចូលគណនីជាមុនសិន។")
        require(title.isNotBlank()) { "សូមបញ្ចូលចំណងជើងរឿង។" }
        require(targetMinutes in 1..90) { "រយៈពេលត្រូវនៅចន្លោះ 1–90 នាទី។" }
        val mimeType = context.contentResolver.getType(videoUri) ?: "video/mp4"
        require(mimeType.startsWith("video/")) { "សូមជ្រើសរើសឯកសារវីដេអូ។" }

        val storyRef = db.collection("stories").document()
        val uid = user.uid
        val storagePath = "users/$uid/stories/${storyRef.id}/source-video/source-video"
        val now = FieldValue.serverTimestamp()

        storyRef.set(
            mapOf(
                "userId" to uid,
                "title" to title.trim(),
                "tone" to tone,
                "targetMinutes" to targetMinutes,
                "status" to "draft",
                "processingStep" to "draft",
                "processingProgress" to 0,
                "createdAt" to now,
                "updatedAt" to now,
                "errorMessage" to null
            )
        ).await()

        try {
            val metadata = StorageMetadata.Builder().setContentType(mimeType).build()
            storage.reference.child(storagePath).putFile(videoUri, metadata).await()
            functions.getHttpsCallable("completeStoryUpload")
                .call(mapOf("storyId" to storyRef.id, "sourceVideoPath" to storagePath))
                .await()
            functions.getHttpsCallable("startStoryProcessing")
                .call(mapOf("storyId" to storyRef.id, "targetMinutes" to targetMinutes))
                .await()
            val saved = storyRef.get().await()
            val finalStatus = saved.getString("status") ?: "queued"
            return Story(
                id = storyRef.id,
                userId = uid,
                title = title.trim(),
                sourceVideoPath = storagePath,
                status = StoryStatus.entries.firstOrNull { it.key == finalStatus } ?: StoryStatus.QUEUED,
                processingStep = saved.getString("processingStep") ?: "queued",
                processingProgress = (saved.getLong("processingProgress") ?: 0L).toInt(),
                tone = tone,
                duration = "$targetMinutes នាទី",
                createdAt = "ទើបបង្កើត"
            )
        } catch (e: Exception) {
            // Client cannot mark backend-owned status fields. The draft remains private;
            // retry or clean it up through a trusted server-side flow.
            throw e
        }
    }
}
