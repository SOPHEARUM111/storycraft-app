const os = require("os");
const path = require("path");
const fs = require("fs");
const fsPromises = require("fs/promises");
const { createHash } = require("node:crypto");

const admin = require("firebase-admin");
const { AggregateField } = require("firebase-admin/firestore");
const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { onDocumentCreated } = require("firebase-functions/v2/firestore");
const { defineSecret } = require("firebase-functions/params");
const { getStorage } = require("firebase-admin/storage");
const OpenAI = require("openai");

if (!admin.apps.length) {
  admin.initializeApp();
}
const db = admin.firestore();
const FieldValue = admin.firestore.FieldValue;

const {
  createNextJob,
  markJobProcessing,
  markJobCompleted,
  markJobError,
} = require("./jobProcessor");

const { extractAudio } = require("./videoProcessor");
const { createAssSubtitle } = require("./subtitleGenerator");
const { runRenderVideo } = require("./renderVideoJob");
const { calculateScriptPlan } = require("./script_length_calculator");
const { splitIntoChunks, createRecapPlan } = require("./script_chunks");
const { assembleScriptChunks } = require("./script_assembly");
const { splitScriptForVoice } = require("./voice_splitter");
const { finalizeStoryVoice } = require("./audio_assembly");
const { renderFinalVideo } = require("./render_final_video");

/**
 * ⏱️ HELPER: VALIDATE RECAP DURATION (1 to 90 minutes)
 */
function validateRecapDuration(value) {
  const minutes = Number(value);

  if (
    !Number.isInteger(minutes) ||
    minutes < 1 ||
    minutes > 90
  ) {
    throw new Error(
      "Duration must be between 1 and 90 minutes."
    );
  }

  return minutes;
}

const openaiApiKey = defineSecret("OPENAI_API_KEY");

async function runExtractAudio(story) {
  const data = story.data;
  if (!data.sourceVideoPath) {
    throw new Error("sourceVideoPath is missing");
  }

  const tempDir = await fsPromises.mkdtemp(path.join(os.tmpdir(), `story-${story.id}-`));
  const inputPath = path.join(tempDir, "input.mp4");
  const outputPath = path.join(tempDir, "audio.mp3");

  try {
    const bucket = getStorage().bucket();
    const videoFile = bucket.file(data.sourceVideoPath);
    await videoFile.download({ destination: inputPath });

    await extractAudio(inputPath, outputPath);

    const sourceAudioPath = `users/${data.userId}/stories/${story.id}/source-audio.mp3`;

    await bucket.upload(outputPath, {
      destination: sourceAudioPath,
      metadata: { contentType: "audio/mpeg" },
    });

    await story.ref.update({
      sourceAudioPath: sourceAudioPath,
      processingStep: "audio_ready",
      processingProgress: 40,
      updatedAt: FieldValue.serverTimestamp(),
    });

    console.log(`Audio uploaded: ${sourceAudioPath}`);
  } finally {
    await fsPromises.rm(tempDir, { recursive: true, force: true });
  }
}

async function runTranscribe(story) {
  const data = story.data;
  const targetAudioPath = data.sourceAudioPath || data.audioPath;

  if (!targetAudioPath) {
    throw new Error("sourceAudioPath is missing");
  }

  const tempDir = await fsPromises.mkdtemp(path.join(os.tmpdir(), `transcribe-${story.id}-`));
  const audioPath = path.join(tempDir, "source-audio.mp3");

  try {
    const bucket = getStorage().bucket();
    const audioFile = bucket.file(targetAudioPath);

    await audioFile.download({ destination: audioPath });

    await story.ref.update({
      processingStep: "transcribing",
      processingProgress: 45,
      updatedAt: FieldValue.serverTimestamp(),
    });

    const openai = new OpenAI({ apiKey: openaiApiKey.value() });
    const transcription = await openai.audio.transcriptions.create({
      file: fs.createReadStream(audioPath),
      model: "whisper-1",
      language: "km",
    });

    const transcript = transcription.text || "";

    if (!transcript.trim()) {
      throw new Error("Transcription returned empty text");
    }

    await story.ref.update({
      transcript: transcript,
      processingStep: "transcript_ready",
      processingProgress: 55,
      updatedAt: FieldValue.serverTimestamp(),
    });

    console.log(`Transcript completed: ${story.id}`);
  } finally {
    await fsPromises.rm(tempDir, { recursive: true, force: true });
  }
}

async function runGenerateRecap(story) {
  const data = story.data;

  if (!data.transcript) {
    throw new Error("Transcript is missing");
  }

  await story.ref.update({
    processingStep: "generating_recap",
    processingProgress: 60,
    updatedAt: FieldValue.serverTimestamp(),
  });

  const targetMinutes = data.targetMinutes || 3;

  const durationInstructions = `
Target duration: ${targetMinutes} minutes.
- Cover the important events in chronological order.
- Explain the characters, conflicts, and major plot twists.
- Maintain a natural narration style.
- Avoid unnecessary repetition and invented plot details.
- Divide the script into manageable sections.
- Aim for the requested spoken duration.
- Return the narration script only in Khmer.
`;

  const prompt = `
អ្នកគឺជាអ្នកសរសេរសម្រាយរឿងភាពយន្តជាភាសាខ្មែរ។

សូមសរសេរសម្រាយរឿងពី Transcript ខាងក្រោម។

${durationInstructions}

ច្បាប់សំខាន់ៗ៖
1. សរសេរជាភាសាខ្មែរដែលងាយស្តាប់។
2. រៀបរាប់តាមលំដាប់ព្រឹត្តិការណ៍។
3. កុំបង្កើតព័ត៌មានដែលមិនមាននៅក្នុង Transcript។
4. រក្សាឈ្មោះតួអង្គ និងព្រឹត្តិការណ៍ឱ្យបានត្រឹមត្រូវតាមព័ត៌មានដែលមាន។
5. សរសេរឱ្យសមស្របសម្រាប់ Voice-over។
6. កុំប្រើ Bullet points។
7. កុំដាក់ Heading។
8. កុំចម្លង Transcript ទាំងមូលដោយផ្ទាល់។
9. ធ្វើឱ្យរឿងមានភាពរលូន និងងាយយល់។
10. កុំបញ្ចូលការពន្យល់ក្រៅពីសាច់រឿង។

Transcript:
${data.transcript}
`;

  const openai = new OpenAI({ apiKey: openaiApiKey.value() });
  const response = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [{ role: "user", content: prompt }],
  });

  const script = response.choices[0]?.message?.content?.trim();

  if (!script) {
    throw new Error("AI returned an empty recap");
  }

  await story.ref.update({
    script: script,
    status: "processing",
    processingStep: "recap_ready",
    processingProgress: 70,
    updatedAt: FieldValue.serverTimestamp(),
  });

  console.log(`Recap completed: ${story.id}`);
}

async function runGenerateVoice(story) {
  const data = story.data;

  if (!data.script) {
    throw new Error("Script is missing");
  }

  await story.ref.update({
    processingStep: "generating_voice",
    processingProgress: 75,
    updatedAt: FieldValue.serverTimestamp(),
  });

  const tempDir = await fsPromises.mkdtemp(
    path.join(
      os.tmpdir(),
      `voice-${story.id}-`
    )
  );

  const outputPath = path.join(
    tempDir,
    "voice.mp3"
  );

  try {
    const openai = new OpenAI({ apiKey: openaiApiKey.value() });
    const voiceChunks = splitScriptForVoice(data.script, 3000);
    const audioBuffers = [];

    for (let i = 0; i < voiceChunks.length; i++) {
      console.log(`Generating TTS audio chunk ${i + 1}/${voiceChunks.length} for story ${story.id}`);
      const speech = await openai.audio.speech.create({
        model: "tts-1",
        voice: "onyx",
        input: voiceChunks[i],
        response_format: "mp3",
      });

      audioBuffers.push(Buffer.from(await speech.arrayBuffer()));
    }

    const fullAudioBuffer = Buffer.concat(audioBuffers);
    await fsPromises.writeFile(outputPath, fullAudioBuffer);

    const bucket = getStorage().bucket();

    const voicePath =
      `users/${data.userId}/stories/${story.id}/voice.mp3`;

    await bucket.upload(outputPath, {
      destination: voicePath,
      metadata: {
        contentType: "audio/mpeg",
      },
    });

    await story.ref.update({
      voicePath: voicePath,
      processingStep: "voice_ready",
      processingProgress: 80,
      updatedAt: FieldValue.serverTimestamp(),
    });

    console.log(
      `Voice completed: ${story.id}`
    );
  } finally {
    await fsPromises.rm(tempDir, {
      recursive: true,
      force: true,
    });
  }
}

async function runGenerateSubtitle(story) {
  const data = story.data;

  if (!data.script || !data.script.trim()) {
    throw new Error("Script is missing for subtitle generation");
  }

  await story.ref.update({
    processingStep: "generating_subtitle",
    processingProgress: 85,
    updatedAt: FieldValue.serverTimestamp(),
  });

  const tempDir = await fsPromises.mkdtemp(path.join(os.tmpdir(), `sub-${story.id}-`));
  const tempSubPath = path.join(tempDir, "subtitle.ass");

  try {
    const assContent = createAssSubtitle(data.script);
    await fsPromises.writeFile(tempSubPath, assContent, "utf8");

    const bucket = getStorage().bucket();
    const subtitlePath = `users/${data.userId}/stories/${story.id}/subtitle.ass`;

    await bucket.upload(tempSubPath, {
      destination: subtitlePath,
      metadata: { contentType: "text/x-ssa" },
    });

    await story.ref.update({
      subtitlePath: subtitlePath,
      processingStep: "subtitle_ready",
      processingProgress: 90,
      updatedAt: FieldValue.serverTimestamp(),
    });

    console.log(`Subtitle generated: ${subtitlePath}`);
  } finally {
    await fsPromises.rm(tempDir, { recursive: true, force: true });
  }
}

async function runGenerateRecapChunk(jobRef, job, story) {
  const sourceText = job.sourceText;
  const chunkIndex = job.chunkIndex;
  const storyId = job.storyId;
  const uid = job.uid || story.data.userId;
  const targetMinutes = job.targetMinutes || 3;

  if (story.data.userId !== uid) {
    throw new Error("Job ownership verification failed");
  }

  if (!sourceText || typeof sourceText !== "string") {
    throw new Error("sourceText is missing for recap chunk generation");
  }

  const prompt = `
អ្នកគឺជាអ្នកសរសេរសម្រាយរឿងភាពយន្តជាភាសាខ្មែរ។

សូមសរសេរសម្រាយរឿងផ្នែកទី ${chunkIndex + 1} ពីអត្ថបទប្រភពខាងក្រោម៖

- Target chunk duration equivalent: ${targetMinutes} minutes scale.
- Cover events accurately in chronological order.
- Maintain natural narration style in Khmer for Voice-over.
- Do not repeat or invent plot details outside the source text.
- Return the narration script section only in Khmer.

Source Text Chunk:
${sourceText}
`;

  const openai = new OpenAI({ apiKey: openaiApiKey.value() });
  const response = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [{ role: "user", content: prompt }],
  });

  const chunkScript = response.choices[0]?.message?.content?.trim();

  if (!chunkScript) {
    throw new Error("AI returned empty recap chunk script");
  }

  const chunkDocRef = db
    .collection("stories")
    .doc(storyId)
    .collection("scriptChunks")
    .doc(String(chunkIndex));

  await chunkDocRef.set({
    chunkIndex,
    script: chunkScript,
    status: "completed",
    updatedAt: FieldValue.serverTimestamp(),
  }, { merge: true });

  console.log(`Recap chunk ${chunkIndex} generated for story: ${storyId}`);
}

/**
 * ⚙️ BACKGROUND TASK DISPATCHER
 */
async function runJob(type, story) {
  switch (type) {
    case "extract_audio":
      return await runExtractAudio(story);
    case "transcribe":
      return await runTranscribe(story);
    case "generate_recap":
      return await runGenerateRecap(story);
    case "generate_voice":
      return await runGenerateVoice(story);
    case "generate_subtitle":
      return await runGenerateSubtitle(story);
    case "render_video":
      return runRenderVideo(story);
    default:
      throw new Error(`Unknown job type: ${type}`);
  }
}

/**
 * ⚙️ BACKGROUND JOB WORKER TRIGGER
 */
exports.processStoryJob = onDocumentCreated(
  {
    document: "storyJobs/{jobId}",
    region: "asia-southeast1",
    timeoutSeconds: 540,
    memory: "2GiB",
    secrets: [openaiApiKey],
  },
  async (event) => {
    const snapshot = event.data;
    if (!snapshot) return;

    const jobRef = snapshot.ref;
    const job = snapshot.data();
    if (!job || job.status !== "queued") return;

    const storyRef = db.collection("stories").doc(job.storyId);
    const storySnapshot = await storyRef.get();

    if (!storySnapshot.exists) {
      await markJobError(jobRef, new Error("Story not found"));
      return;
    }

    const story = {
      id: storySnapshot.id,
      data: storySnapshot.data(),
      ref: storyRef,
    };

    try {
      await markJobProcessing(jobRef);

      await storyRef.update({
        status: "processing",
        processingStep: job.type,
        updatedAt: FieldValue.serverTimestamp(),
      });

      console.log(`Processing job: ${job.type}`);
      if (job.type === "generate_recap_chunk") {
        // 1. Validate job ownership and input.
        if (story.data.userId !== (job.uid || story.data.userId)) {
          throw new Error("Job ownership verification failed");
        }
        if (!job.sourceText || typeof job.sourceText !== "string") {
          throw new Error("sourceText is missing for recap chunk generation");
        }

        // 2. Generate narration from job.sourceText.
        await runGenerateRecapChunk(jobRef, job, story);

        // 3. Save the result to:
        //    stories/{storyId}/scriptChunks/{chunkIndex}
        // (Handled inside runGenerateRecapChunk)

        // 4. Mark this job completed or error.
        await markJobCompleted(jobRef);

        const storySnap = await storyRef.get();
        const sData = storySnap.data();
        const chunkCount = sData.scriptChunkCount || 1;
        const chunksSnap = await storyRef.collection("scriptChunks").get();

        if (chunksSnap.size >= chunkCount) {
          await assembleStoryScript(story.id, story.data.userId);

          await storyRef.update({
            processingStep: "recap_ready",
            processingProgress: 70,
            updatedAt: FieldValue.serverTimestamp(),
          });

          const nextJobRef = db.collection("storyJobs").doc();
          await nextJobRef.set({
            storyId: story.id,
            userId: story.data.userId,
            type: "generate_voice",
            status: "queued",
            attempts: 0,
            errorMessage: null,
            createdAt: FieldValue.serverTimestamp(),
            updatedAt: FieldValue.serverTimestamp(),
          });
        }
      } else {
        await runJob(job.type, story);
        await markJobCompleted(jobRef);
        await createNextJob(story, job.type);
      }

    } catch (error) {
      console.error(`Job failed: ${job.type}`, error);
      const errorMessage = String(error.message || error).slice(0, 1000);

      await jobRef.update({
        status: "error",
        errorMessage: errorMessage,
        updatedAt: FieldValue.serverTimestamp(),
      });

      await db.collection("stories").doc(job.storyId).update({
        status: "error",
        lastFailedJobId: jobRef.id,
        retryInProgress: false,
        errorMessage: errorMessage,
        updatedAt: FieldValue.serverTimestamp(),
      });

      await createAdminAlert({
        type: "job_failed",
        title: "Story processing failed",
        message: `Job ${jobRef.id} failed. Please review the error logs.`,
        jobId: jobRef.id,
        storyId: job.storyId,
      }).catch((alertErr) =>
        console.error("Failed to create admin alert:", alertErr)
      );
    }
  }
);

/**
 * 🔄 CALLABLE STORY JOB RETRY HANDLER
 */
exports.retryStoryJob = onCall(
  { region: "asia-southeast1" },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError(
        "unauthenticated",
        "សូមចូលគណនីជាមុនសិន។"
      );
    }

    const { storyId } = request.data || {};

    if (
      typeof storyId !== "string" ||
      !/^[A-Za-z0-9_-]{1,150}$/.test(storyId)
    ) {
      throw new HttpsError(
        "invalid-argument",
        "storyId មិនត្រឹមត្រូវ។"
      );
    }

    const uid = request.auth.uid;
    const storyRef = db.collection("stories").doc(storyId);
    const jobsRef = db.collection("storyJobs");
    const newJobRef = jobsRef.doc();

    await db.runTransaction(async (tx) => {
      const storySnap = await tx.get(storyRef);

      if (!storySnap.exists) {
        throw new HttpsError("not-found", "រកមិនឃើញ Story ទេ។");
      }

      const story = storySnap.data();

      if (story.userId !== uid) {
        throw new HttpsError(
          "permission-denied",
          "អ្នកមិនមែនជាម្ចាស់ Story នេះទេ។"
        );
      }

      if (story.status !== "error") {
        throw new HttpsError(
          "failed-precondition",
          "អាច Retry បានតែ Story ដែលបរាជ័យប៉ុណ្ណោះ។"
        );
      }

      if (story.retryInProgress === true) {
        throw new HttpsError(
          "already-exists",
          "ការសាកល្បងម្ដងទៀតកំពុងដំណើរការ។"
        );
      }

      const failedJobId = story.lastFailedJobId;

      if (!failedJobId) {
        throw new HttpsError(
          "failed-precondition",
          "រកមិនឃើញ Job ដែលបរាជ័យសម្រាប់ Retry ទេ។"
        );
      }

      const failedJobRef = jobsRef.doc(failedJobId);
      const failedJobSnap = await tx.get(failedJobRef);

      if (!failedJobSnap.exists) {
        throw new HttpsError("not-found", "រកមិនឃើញ Job ចាស់ទេ។");
      }

      const failedJob = failedJobSnap.data();

      if (
        failedJob.storyId !== storyId ||
        failedJob.userId !== uid ||
        failedJob.status !== "error"
      ) {
        throw new HttpsError(
          "failed-precondition",
          "Job ចាស់មិនអាច Retry បានទេ។"
        );
      }

      const attempts = Number(failedJob.attempts || 0);

      if (attempts >= 3) {
        throw new HttpsError(
          "resource-exhausted",
          "Job នេះបានសាកល្បងគ្រប់ 3 ដងហើយ។"
        );
      }

      const newJob = {
        storyId,
        userId: uid,
        type: failedJob.type,
        status: "queued",
        attempts: attempts + 1,
        errorMessage: null,
        createdAt: FieldValue.serverTimestamp(),
        updatedAt: FieldValue.serverTimestamp(),
      };

      tx.create(newJobRef, newJob);

      tx.update(storyRef, {
        status: "queued",
        processingStep: "queued",
        processingProgress: 0,
        errorMessage: null,
        retryInProgress: true,
        activeJobId: newJobRef.id,
        updatedAt: FieldValue.serverTimestamp(),
      });
    });

    return {
      success: true,
      jobId: newJobRef.id,
    };
  }
);

/**
 * 🚀 CALLABLE SOCIAL METADATA GENERATOR
 */
exports.generateSocialPost = onCall(
  {
    region: "asia-southeast1",
    secrets: [openaiApiKey],
  },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError("unauthenticated", "Please login first.");
    }

    const { storyId } = request.data;
    if (!storyId) {
      throw new HttpsError("invalid-argument", "storyId is required.");
    }

    const storyRef = db.collection("stories").doc(storyId);
    const storySnap = await storyRef.get();

    if (!storySnap.exists) {
      throw new HttpsError("not-found", "Story not found.");
    }

    const story = storySnap.data();

    if (story.userId !== request.auth.uid) {
      throw new HttpsError("permission-denied", "You do not own this story.");
    }

    const openai = new OpenAI({ apiKey: openaiApiKey.value() });

    const prompt = `
អ្នកគឺជា Social Media Content Creator សម្រាប់វីដេអូសម្រាយរឿងជាភាសាខ្មែរ។
សូមបង្កើត Content ជា JSON សម្រាប់ YouTube Shorts, TikTok និង Facebook Reels៖
{
  "title": "ចំណងជើងខ្លីមាន Hook ក្រោម ៦០ អក្សរ",
  "description": "Caption Teaser សង្ខេប ២-៣ បន្ទាត់",
  "hashtags": ["#សម្រាយរឿង", "#Shorts", "#MovieRecap", "#Khmer"],
  "tags": ["សម្រាយរឿង", "movie recap", "shorts"]
}

SCRIPT:
${story.script || story.transcript || story.title}
`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      response_format: { type: "json_object" },
      messages: [{ role: "user", content: prompt }],
    });

    const result = JSON.parse(response.choices[0].message.content);

    await storyRef.update({
      socialTitle: result.title || "",
      socialDescription: result.description || "",
      hashtags: Array.isArray(result.hashtags) ? result.hashtags : [],
      tags: Array.isArray(result.tags) ? result.tags : [],
      socialStatus: "ready",
      updatedAt: FieldValue.serverTimestamp(),
    });

    return result;
  }
);

/**
 * 🔒 CALLABLE ADMIN ACCESS CHECK
 */
exports.checkAdminAccess = onCall(
  { region: "asia-southeast1" },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError(
        "unauthenticated",
        "សូមចូលគណនីជាមុន។"
      );
    }

    if (request.auth.token.admin !== true) {
      throw new HttpsError(
        "permission-denied",
        "អ្នកមិនមានសិទ្ធិ Admin ទេ។"
      );
    }

    return { isAdmin: true };
  }
);

/**
 * 📊 CALLABLE ADMIN JOB STATS AGGREGATOR
 */
exports.getAdminJobStats = onCall(
  { region: "asia-southeast1" },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError(
        "unauthenticated",
        "សូមចូលគណនីជាមុន។"
      );
    }

    if (request.auth.token.admin !== true) {
      throw new HttpsError(
        "permission-denied",
        "ត្រូវការសិទ្ធិ Admin។"
      );
    }

    const jobs = db.collection("storyJobs");

    const statuses = [
      "queued",
      "processing",
      "completed",
      "error",
      "stale",
    ];

    const counts = await Promise.all(
      statuses.map(async (status) => {
        const result = await jobs
          .where("status", "==", status)
          .count()
          .get();

        return [status, result.data().count];
      })
    );

    const countByStatus = Object.fromEntries(counts);

    const totalResult = await jobs.count().get();

    const completedQuery = jobs
      .where("status", "==", "completed")
      .where("durationMs", ">", 0);

    const durationResult = await completedQuery
      .aggregate({
        averageDurationMs:
          AggregateField.average("durationMs"),
      })
      .get();

    const averageDurationMs =
      durationResult.data().averageDurationMs;

    return {
      total: totalResult.data().count,
      counts: countByStatus,
      averageDurationMs:
        averageDurationMs == null
          ? null
          : Math.round(averageDurationMs),
      updatedAt: new Date().toISOString(),
    };
  }
);

/**
 * 🇰🇭 CAMBODIA TIMEZONE DATE KEY (Asia/Phnom_Penh)
 */
const DAILY_VIDEO_LIMIT = 3;

function getCambodiaDateKey(date = new Date()) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Phnom_Penh",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(date);

  const values = {};
  for (const part of parts) {
    if (part.type !== "literal") {
      values[part.type] = part.value;
    }
  }

  return `${values.year}-${values.month}-${values.day}`;
}

const cambodiaDateKey = getCambodiaDateKey;

function getRecentDateKeys(today, numberOfDays = 7) {
  const baseDate = new Date(`${today}T00:00:00Z`);
  const dates = [];

  for (let i = 0; i < numberOfDays; i++) {
    const date = new Date(baseDate);
    date.setUTCDate(baseDate.getUTCDate() - i);
    dates.push(date.toISOString().slice(0, 10));
  }

  return dates;
}

/**
 * Confirm a completed source-video upload without allowing the Android client
 * to write backend-managed story status or storage paths directly.
 */
exports.completeStoryUpload = onCall(
  { region: "asia-southeast1" },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError("unauthenticated", "សូមចូលគណនីជាមុនសិន។");
    }

    const { storyId, sourceVideoPath } = request.data || {};
    if (typeof storyId !== "string" || !/^[A-Za-z0-9_-]{1,150}$/.test(storyId)) {
      throw new HttpsError("invalid-argument", "storyId មិនត្រឹមត្រូវ។");
    }

    const uid = request.auth.uid;
    const expectedPath = `users/${uid}/stories/${storyId}/source-video/source-video`;
    if (sourceVideoPath !== expectedPath) {
      throw new HttpsError("invalid-argument", "ទីតាំងវីដេអូមិនត្រឹមត្រូវ។");
    }

    const storyRef = db.collection("stories").doc(storyId);
    const storySnap = await storyRef.get();
    if (!storySnap.exists) {
      throw new HttpsError("not-found", "រកមិនឃើញ Story ទេ។");
    }
    const story = storySnap.data();
    if (story.userId !== uid) {
      throw new HttpsError("permission-denied", "អ្នកមិនមែនជាម្ចាស់ Story នេះទេ។");
    }
    if (story.status !== "draft") {
      throw new HttpsError("failed-precondition", "Story នេះមិនស្ថិតក្នុងស្ថានភាព draft ទេ។");
    }

    const file = getStorage().bucket().file(expectedPath);
    const [exists] = await file.exists();
    if (!exists) {
      throw new HttpsError("failed-precondition", "មិនទាន់រកឃើញវីដេអូដែលបាន Upload ទេ។");
    }
    const [metadata] = await file.getMetadata();
    const size = Number(metadata.size || 0);
    const contentType = String(metadata.contentType || "");
    if (size <= 0 || size >= 500 * 1024 * 1024 || !contentType.startsWith("video/")) {
      throw new HttpsError("invalid-argument", "ឯកសារវីដេអូមិនត្រឹមត្រូវ ឬធំពេក។");
    }

    await storyRef.update({
      sourceVideoPath: expectedPath,
      status: "uploaded",
      processingStep: "uploaded",
      processingProgress: 0,
      updatedAt: FieldValue.serverTimestamp(),
    });

    return { success: true, storyId, sourceVideoPath: expectedPath };
  }
);

/**
 * 🚀 CALLABLE START STORY PROCESSING (Transaction-Safe & Quota-Guarded)
 */
exports.startStoryProcessing = onCall(
  { region: "asia-southeast1" },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError(
        "unauthenticated",
        "សូមចូលគណនីជាមុន។"
      );
    }

    const { storyId } = request.data || {};

    if (
      typeof storyId !== "string" ||
      !/^[A-Za-z0-9_-]{1,150}$/.test(storyId)
    ) {
      throw new HttpsError(
        "invalid-argument",
        "storyId មិនត្រឹមត្រូវ។"
      );
    }

    let targetMinutes = null;
    if (request.data.targetMinutes !== undefined) {
      try {
        targetMinutes = validateRecapDuration(request.data.targetMinutes);
      } catch (err) {
        throw new HttpsError("invalid-argument", err.message);
      }
    }

    const uid = request.auth.uid;
    const dateKey = cambodiaDateKey();

    const storyRef = db.collection("stories").doc(storyId);
    const usageRef = db
      .collection("users")
      .doc(uid)
      .collection("dailyUsage")
      .doc(dateKey);

    const jobRef = db.collection("storyJobs").doc();

    return db.runTransaction(async (tx) => {
      // Read all documents before writing.
      const storySnap = await tx.get(storyRef);
      const usageSnap = await tx.get(usageRef);

      if (!storySnap.exists) {
        throw new HttpsError(
          "not-found",
          "រកមិនឃើញ Story ទេ។"
        );
      }

      const story = storySnap.data();

      if (story.userId !== uid) {
        throw new HttpsError(
          "permission-denied",
          "អ្នកមិនមែនជាម្ចាស់ Story នេះទេ។"
        );
      }

      if (!story.sourceVideoPath) {
        throw new HttpsError(
          "failed-precondition",
          "សូម Upload វីដេអូជាមុនសិន។"
        );
      }

      const allowedStatuses = ["uploaded", "draft"];

      if (!allowedStatuses.includes(story.status)) {
        throw new HttpsError(
          "failed-precondition",
          "Story នេះមិនអាចចាប់ផ្ដើមបានទេ។"
        );
      }

      const currentCount = usageSnap.exists
        ? Number(usageSnap.data().videosStarted || 0)
        : 0;

      if (currentCount >= DAILY_VIDEO_LIMIT) {
        throw new HttpsError(
          "resource-exhausted",
          `អ្នកបានប្រើកូតា ${DAILY_VIDEO_LIMIT} វីដេអូសម្រាប់ថ្ងៃនេះអស់ហើយ។`
        );
      }

      const now = FieldValue.serverTimestamp();

      tx.set(
        usageRef,
        {
          date: dateKey,
          userId: uid,
          videosStarted: currentCount + 1,
          updatedAt: now,
        },
        { merge: true }
      );

      tx.create(jobRef, {
        storyId,
        userId: uid,
        type: "extract_audio",
        status: "queued",
        attempts: 0,
        errorMessage: null,
        createdAt: now,
        updatedAt: now,
      });

      const storyUpdateData = {
        status: "queued",
        processingStep: "queued",
        processingProgress: 0,
        activeJobId: jobRef.id,
        errorMessage: null,
        updatedAt: now,
      };

      if (targetMinutes !== null) {
        storyUpdateData.targetMinutes = targetMinutes;
      }

      tx.update(storyRef, storyUpdateData);

      return {
        success: true,
        jobId: jobRef.id,
        videosStarted: currentCount + 1,
        dailyLimit: DAILY_VIDEO_LIMIT,
      };
    });
  }
);

/**
 * 📊 CALLABLE GET MY DAILY USAGE (7-Day History & Cambodia Quota)
 */
exports.getMyDailyUsage = onCall(
  { region: "asia-southeast1" },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError(
        "unauthenticated",
        "សូមចូលគណនីជាមុនសិន។"
      );
    }

    const uid = request.auth.uid;
    const today = getCambodiaDateKey();

    const dateKeys = getRecentDateKeys(today, 7);

    const snapshots = await Promise.all(
      dateKeys.map((date) =>
        db
          .collection("users")
          .doc(uid)
          .collection("dailyUsage")
          .doc(date)
          .get()
      )
    );

    const history = snapshots.map((snapshot, index) => ({
      date: dateKeys[index],
      videosStarted: snapshot.exists
        ? Number(snapshot.get("videosStarted") || 0)
        : 0,
    }));

    const used = history[0]?.videosStarted ?? 0;
    const limit = DAILY_VIDEO_LIMIT;

    return {
      date: today,
      used,
      limit,
      remaining: Math.max(0, limit - used),
      history,
    };
  }
);

/**
 * 👑 CALLABLE ADMIN SYSTEM USAGE AGGREGATOR
 */
exports.getAdminUsageStats = onCall(
  { region: "asia-southeast1" },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError(
        "unauthenticated",
        "សូមចូលគណនីជាមុនសិន។"
      );
    }

    if (request.auth.token.admin !== true) {
      throw new HttpsError(
        "permission-denied",
        "អ្នកមិនមានសិទ្ធិ Admin ទេ។"
      );
    }

    const today = getCambodiaDateKey();

    const [usersCount, storiesCount, jobsCount, todayUsage] =
      await Promise.all([
        db.collection("users").count().get(),
        db.collection("stories").count().get(),
        db.collection("storyJobs").count().get(),

        db.collectionGroup("dailyUsage")
          .where("date", "==", today)
          .get()
          .catch(() =>
            db.collectionGroup("dailyUsage")
              .where("dateKey", "==", today)
              .get()
          ),
      ]);

    const totalVideosStartedToday = todayUsage.docs.reduce(
      (sum, doc) =>
        sum + Number(doc.get("videosStarted") || 0),
      0
    );

    const [queued, processing, completed, errors] =
      await Promise.all([
        db.collection("storyJobs")
          .where("status", "==", "queued").count().get(),
        db.collection("storyJobs")
          .where("status", "==", "processing").count().get(),
        db.collection("storyJobs")
          .where("status", "==", "completed").count().get(),
        db.collection("storyJobs")
          .where("status", "in", ["error", "stale"])
          .count().get(),
      ]);

    return {
      date: today,
      users: usersCount.data().count,
      stories: storiesCount.data().count,
      jobs: jobsCount.data().count,
      videosStartedToday: totalVideosStartedToday,
      jobsByStatus: {
        queued: queued.data().count,
        processing: processing.data().count,
        completed: completed.data().count,
        errors: errors.data().count,
      },
    };
  }
);

/**
 * 🔍 CALLABLE ADMIN FIND USER (By Email or UID)
 */
exports.adminFindUser = onCall(
  { region: "asia-southeast1" },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError(
        "unauthenticated",
        "សូមចូលគណនីជាមុនសិន។"
      );
    }

    if (request.auth.token.admin !== true) {
      throw new HttpsError(
        "permission-denied",
        "អ្នកមិនមានសិទ្ធិ Admin ទេ។"
      );
    }

    const query = String(request.data?.query || "").trim();

    if (query.length < 3 || query.length > 200) {
      throw new HttpsError(
        "invalid-argument",
        "សូមបញ្ចូលអ៊ីមែលពេញលេញ ឬ UID ដែលត្រឹមត្រូវ។"
      );
    }

    let user;

    try {
      if (query.includes("@")) {
        user = await admin.auth().getUserByEmail(
          query.toLowerCase()
        );
      } else {
        user = await admin.auth().getUser(query);
      }
    } catch (error) {
      if (error.code === "auth/user-not-found") {
        return { found: false };
      }
      throw error;
    }

    const profile = await db
      .collection("users")
      .doc(user.uid)
      .get();

    return {
      found: true,
      uid: user.uid,
      email: user.email || "",
      displayName:
        user.displayName ||
        profile.get("name") ||
        "",
      disabled: user.disabled,
      isAdmin: user.customClaims?.admin === true,
      createdAt: user.metadata.creationTime || null,
      lastSignInAt: user.metadata.lastSignInTime || null,
    };
  }
);

/**
 * 📱 HELPER: SEND ADMIN PUSH ALERT
 */
async function sendAdminPushAlert({
  type,
  title,
  body,
  jobId = "",
  storyId = "",
}) {
  try {
    const adminDevicesSnapshot = await db
      .collection("adminDevices")
      .get();

    const sendTasks = [];

    for (const deviceDoc of adminDevicesSnapshot.docs) {
      const tokensSnapshot = await deviceDoc.ref
        .collection("tokens")
        .get();

      for (const tokenDoc of tokensSnapshot.docs) {
        const token = tokenDoc.get("token");

        if (!token) continue;

        sendTasks.push(
          (async () => {
            try {
              await admin.messaging().send({
                token,
                notification: {
                  title,
                  body,
                },
                data: {
                  type: String(type || "admin_alert"),
                  jobId: String(jobId || ""),
                  storyId: String(storyId || ""),
                },
                android: {
                  priority: "high",
                  notification: {
                    channelId: "story_recap_alerts",
                  },
                },
              });
            } catch (error) {
              const invalidTokenCodes = [
                "messaging/registration-token-not-registered",
                "messaging/invalid-registration-token",
              ];

              if (invalidTokenCodes.includes(error.code)) {
                await tokenDoc.ref.delete().catch(() => {});
              } else {
                console.error(
                  "Admin push notification failed:",
                  error.code || "unknown_error"
                );
              }
            }
          })()
        );
      }
    }

    await Promise.allSettled(sendTasks);
  } catch (error) {
    console.error(
      "Admin push dispatch failed:",
      error.code || "unknown_error"
    );
  }
}

/**
 * 🔔 HELPER: CREATE ADMIN ALERT
 */
async function createAdminAlert({
  type,
  title,
  message,
  jobId = null,
  storyId = null,
}) {
  await db.collection("adminAlerts").add({
    type,
    title,
    message,
    jobId,
    storyId,
    status: "unread",
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
  });

  await sendAdminPushAlert({
    type: "job_failed",
    title: "Story Recap AI: Job Failed",
    body: "A story processing job has failed. Please check Admin Alerts.",
    jobId,
    storyId,
  });
}

/**
 * 📝 HELPER: WRITE ADMIN AUDIT LOG
 */
async function writeAdminAuditLog({
  request,
  action,
  targetUid,
  details = {},
}) {
  await db.collection("adminAuditLogs").add({
    actorUid: request.auth.uid,
    actorEmail: request.auth.token.email || null,
    action,
    targetUid,
    details,
    createdAt: FieldValue.serverTimestamp(),
  });
}

/**
 * 🔒 CALLABLE ADMIN SET USER DISABLED (Ban/Unban User)
 */
exports.adminSetUserDisabled = onCall(
  { region: "asia-southeast1" },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError(
        "unauthenticated",
        "សូមចូលគណនីជាមុនសិន។"
      );
    }

    if (request.auth.token.admin !== true) {
      throw new HttpsError(
        "permission-denied",
        "អ្នកមិនមានសិទ្ធិ Admin ទេ។"
      );
    }

    const uid = String(request.data?.uid || "").trim();
    const disabled = request.data?.disabled;

    if (!uid || typeof disabled !== "boolean") {
      throw new HttpsError(
        "invalid-argument",
        "ទិន្នន័យមិនត្រឹមត្រូវ។"
      );
    }

    if (uid === request.auth.uid) {
      throw new HttpsError(
        "failed-precondition",
        "មិនអាចបិទគណនី Admin ដែលកំពុងប្រើបានទេ។"
      );
    }

    let target;

    try {
      target = await admin.auth().getUser(uid);
    } catch (error) {
      if (error.code === "auth/user-not-found") {
        throw new HttpsError(
          "not-found",
          "រកមិនឃើញគណនីនេះទេ។"
        );
      }
      throw error;
    }

    // កុំឱ្យបិទគណនី Admin តាមមុខងារនេះ។
    if (target.customClaims?.admin === true && disabled) {
      throw new HttpsError(
        "failed-precondition",
        "សូមប្រើនីតិវិធីគ្រប់គ្រង Admin ដាច់ដោយឡែក។"
      );
    }

    await admin.auth().updateUser(uid, { disabled });

    await writeAdminAuditLog({
      request,
      action: disabled ? "user_disabled" : "user_enabled",
      targetUid: uid,
      details: {
        disabled,
      },
    });

    return {
      success: true,
      uid,
      disabled,
    };
  }
);

/**
 * 📝 CALLABLE GET ADMIN AUDIT LOGS (Latest 50 Entries)
 */
exports.getAdminAuditLogs = onCall(
  { region: "asia-southeast1" },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError(
        "unauthenticated",
        "សូមចូលគណនីជាមុនសិន។"
      );
    }

    if (request.auth.token.admin !== true) {
      throw new HttpsError(
        "permission-denied",
        "អ្នកមិនមានសិទ្ធិ Admin ទេ។"
      );
    }

    const snapshot = await db
      .collection("adminAuditLogs")
      .orderBy("createdAt", "desc")
      .limit(50)
      .get();

    return {
      logs: snapshot.docs.map((doc) => {
        const data = doc.data();

        return {
          id: doc.id,
          actorUid: data.actorUid || "",
          actorEmail: data.actorEmail || "",
          action: data.action || "",
          targetUid: data.targetUid || "",
          details: data.details || {},
          createdAt: data.createdAt
            ? data.createdAt.toDate().toISOString()
            : null,
        };
      }),
    };
  }
);

/**
 * 🔔 CALLABLE GET ADMIN ALERTS (Latest 50 Entries)
 */
exports.getAdminAlerts = onCall(
  { region: "asia-southeast1" },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError(
        "unauthenticated",
        "សូមចូលគណនីជាមុនសិន។"
      );
    }

    if (request.auth.token.admin !== true) {
      throw new HttpsError(
        "permission-denied",
        "អ្នកមិនមានសិទ្ធិ Admin ទេ។"
      );
    }

    const snapshot = await db
      .collection("adminAlerts")
      .orderBy("createdAt", "desc")
      .limit(50)
      .get();

    return {
      alerts: snapshot.docs.map((doc) => {
        const data = doc.data();

        return {
          id: doc.id,
          type: data.type || "",
          title: data.title || "",
          message: data.message || "",
          jobId: data.jobId || "",
          storyId: data.storyId || "",
          status: data.status || "unread",
          createdAt: data.createdAt
            ? data.createdAt.toDate().toISOString()
            : null,
        };
      }),
    };
  }
);

/**
 * 👁️ CALLABLE MARK ADMIN ALERT READ
 */
exports.markAdminAlertRead = onCall(
  { region: "asia-southeast1" },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError(
        "unauthenticated",
        "សូមចូលគណនីជាមុនសិន។"
      );
    }

    if (request.auth.token.admin !== true) {
      throw new HttpsError(
        "permission-denied",
        "អ្នកមិនមានសិទ្ធិ Admin ទេ។"
      );
    }

    const alertId = String(
      request.data?.alertId || ""
    ).trim();

    if (!alertId) {
      throw new HttpsError(
        "invalid-argument",
        "ត្រូវការលេខសម្គាល់ Alert។"
      );
    }

    const ref = db.collection("adminAlerts").doc(alertId);
    const snapshot = await ref.get();

    if (!snapshot.exists) {
      throw new HttpsError(
        "not-found",
        "រកមិនឃើញ Alert នេះទេ។"
      );
    }

    await ref.update({
      status: "read",
      readAt: admin.firestore.FieldValue.serverTimestamp(),
      readBy: request.auth.uid,
    });

    return { success: true };
  }
);

/**
 * 📱 CALLABLE REGISTER ADMIN DEVICE (FCM Token Registration)
 */
exports.registerAdminDevice = onCall(
  { region: "asia-southeast1" },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError(
        "unauthenticated",
        "សូមចូលគណនីជាមុនសិន។"
      );
    }

    if (request.auth.token.admin !== true) {
      throw new HttpsError(
        "permission-denied",
        "មានតែ Admin ប៉ុណ្ណោះដែលអាចចុះឈ្មោះឧបករណ៍បាន។"
      );
    }

    const token = String(
      request.data?.token || ""
    ).trim();

    if (!token || token.length > 4096) {
      throw new HttpsError(
        "invalid-argument",
        "FCM Token មិនត្រឹមត្រូវ។"
      );
    }

    const uid = request.auth.uid;

    const tokenId = createHash("sha256")
      .update(token)
      .digest("hex");

    await db.collection("adminDevices")
      .doc(uid)
      .collection("tokens")
      .doc(tokenId)
      .set({
        token,
        updatedAt:
          admin.firestore.FieldValue.serverTimestamp(),
      });

    return { success: true };
  }
);

/**
 * ⚠️ CALLABLE CHECK STUCK JOBS (Detects stale processing jobs & triggers job_stuck alert)
 */
exports.checkStuckJobs = onCall(
  { region: "asia-southeast1" },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError(
        "unauthenticated",
        "សូមចូលគណនីជាមុនសិន។"
      );
    }

    if (request.auth.token.admin !== true) {
      throw new HttpsError(
        "permission-denied",
        "អ្នកមិនមានសិទ្ធិ Admin ទេ។"
      );
    }

    const threshold = new Date(Date.now() - 10 * 60 * 1000); // 10 minutes ago

    const stuckSnapshot = await db
      .collection("storyJobs")
      .where("status", "==", "processing")
      .where("heartbeatAt", "<", threshold)
      .get();

    let stuckCount = 0;

    for (const doc of stuckSnapshot.docs) {
      const job = doc.data();
      const jobId = doc.id;
      const storyId = job.storyId;

      await doc.ref.update({
        status: "stale",
        errorMessage: "Job heartbeat timed out (stale)",
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      if (storyId) {
        await db.collection("stories").doc(storyId).update({
          status: "error",
          errorMessage: "Job timed out in processing",
          updatedAt: admin.firestore.FieldValue.serverTimestamp(),
        }).catch(() => {});
      }

      await createAdminAlert({
        type: "job_stuck",
        title: "Story Recap AI: Job Stuck",
        message: "A story processing job may be stuck. Please check Admin Alerts.",
        jobId,
        storyId,
      });

      stuckCount++;
    }

    return {
      success: true,
      stuckJobsMarked: stuckCount,
    };
  }
);

/**
 * 📦 HELPER: ENQUEUE RECAP CHUNKS (Batched chunk jobs creation)
 */
async function enqueueRecapChunks({
  storyId,
  uid,
  targetMinutes,
  transcript,
}) {
  const plan = createRecapPlan(targetMinutes);
  const chunks = splitIntoChunks(
    transcript,
    plan.chunkCount
  );

  const batch = db.batch();
  const now = admin.firestore.FieldValue.serverTimestamp();

  for (const chunk of chunks) {
    const jobRef = db.collection("storyJobs").doc();

    batch.set(jobRef, {
      type: "generate_recap_chunk",
      storyId,
      uid,
      targetMinutes,
      chunkIndex: chunk.index,
      totalChunks: chunks.length,
      sourceText: chunk.sourceText,
      status: "queued",
      createdAt: now,
      updatedAt: now,
    });
  }

  batch.set(
    db.collection("stories").doc(storyId),
    {
      targetMinutes,
      scriptChunkCount: chunks.length,
      processingStep: "generating_recap",
      processingProgress: 0,
      updatedAt: now,
    },
    { merge: true }
  );

  await batch.commit();

  return {
    storyId,
    targetMinutes,
    chunkCount: chunks.length,
  };
}

/**
 * 🧩 HELPER: ASSEMBLE STORY SCRIPT
 */
async function assembleStoryScript(storyId, uid) {
  const storyRef = db.collection("stories").doc(storyId);
  const storySnap = await storyRef.get();

  if (!storySnap.exists) {
    throw new Error("Story not found.");
  }

  const story = storySnap.data();

  if ((story.uid || story.userId) !== uid) {
    throw new Error("Story ownership check failed.");
  }

  const expectedCount = story.scriptChunkCount;

  if (
    !Number.isInteger(expectedCount) ||
    expectedCount < 1 ||
    expectedCount > 18
  ) {
    throw new Error("Invalid script chunk count.");
  }

  const chunksSnap = await storyRef
    .collection("scriptChunks")
    .get();

  const chunks = chunksSnap.docs.map((doc) => ({
    ...doc.data(),
    chunkIndex: Number(doc.data().chunkIndex),
  }));

  // Ensure all expected chunks exist and are completed.
  const indices = new Set(chunks.map((c) => c.chunkIndex));

  for (let i = 0; i < expectedCount; i++) {
    if (!indices.has(i)) {
      throw new Error(`Missing script chunk ${i}.`);
    }
  }

  if (chunks.length !== expectedCount) {
    throw new Error("Unexpected number of script chunks.");
  }

  const result = assembleScriptChunks(chunks);

  await storyRef.set({
    script: result.script,
    scriptStatus: "assembled",
    scriptQuality: {
      status: result.qualityStatus,
      chunkCount: result.chunkCount,
      removedDuplicates: result.removedDuplicates,
      characterCount: result.characterCount,
      checkedAt: admin.firestore.FieldValue.serverTimestamp(),
    },
    processingStep: "script_quality_check",
    updatedAt: admin.firestore.FieldValue.serverTimestamp(),
  }, { merge: true });

  return {
    success: true,
    chunkCount: result.chunkCount,
    removedDuplicates: result.removedDuplicates,
    characterCount: result.characterCount,
    qualityStatus: result.qualityStatus,
  };
}

/**
 * 🧩 CALLABLE ASSEMBLE STORY SCRIPT
 */
exports.assembleStoryScript = onCall(
  { region: "asia-southeast1" },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError("unauthenticated", "សូមចូលគណនីជាមុនសិន។");
    }

    const { storyId } = request.data || {};
    if (typeof storyId !== "string" || !storyId) {
      throw new HttpsError("invalid-argument", "storyId មិនត្រឹមត្រូវ។");
    }

    try {
      return await assembleStoryScript(storyId, request.auth.uid);
    } catch (err) {
      throw new HttpsError("invalid-argument", err.message);
    }
  }
);

/**
 * 🎬 CALLABLE GENERATE RECAP SCRIPT (With targetMinutes validation & OpenAI GPT)
 */
exports.generateRecapScript = onCall(
  { region: "asia-southeast1", secrets: [openaiApiKey] },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError(
        "unauthenticated",
        "សូមចូលគណនីជាមុនសិន។"
      );
    }

    const { storyId, targetMinutes: rawMinutes } = request.data || {};

    if (
      typeof storyId !== "string" ||
      !/^[A-Za-z0-9_-]{1,150}$/.test(storyId)
    ) {
      throw new HttpsError(
        "invalid-argument",
        "storyId មិនត្រឹមត្រូវ។"
      );
    }

    let targetMinutes = 3;
    if (rawMinutes !== undefined) {
      try {
        targetMinutes = validateRecapDuration(rawMinutes);
      } catch (err) {
        throw new HttpsError("invalid-argument", err.message);
      }
    }

    const uid = request.auth.uid;
    const storyRef = db.collection("stories").doc(storyId);
    const storySnap = await storyRef.get();

    if (!storySnap.exists) {
      throw new HttpsError("not-found", "រកមិនឃើញ Story ទេ។");
    }

    const story = storySnap.data();

    if (story.userId !== uid) {
      throw new HttpsError(
        "permission-denied",
        "អ្នកមិនមែនជាម្ចាស់ Story នេះទេ។"
      );
    }

    if (!story.transcript) {
      throw new HttpsError(
        "failed-precondition",
        "Transcript មិនទាន់មានទេ។ សូមធ្វើការ Transcribe ជាមុនសិន។"
      );
    }

    const plan = calculateScriptPlan(targetMinutes);

    const prompt = `
អ្នកគឺជាអ្នកសរសេរសម្រាយរឿងភាពយន្តជាភាសាខ្មែរ។

សូមសរសេរសម្រាយរឿងពី Transcript ខាងក្រោម។

Target duration: ${plan.targetMinutes} minutes.
Approximate target length: ${plan.targetWords} words.
Narration speed assumption: ${plan.wordsPerMinute} words per minute.

Instructions:
- Follow the movie's actual chronological events.
- Include important characters and plot developments.
- Do not invent scenes or repeat information unnecessarily.
- Write naturally for spoken narration in Khmer.
- Generate the script in sections if it is too long for one response.
- Return the narration script only in Khmer.

Transcript:
${story.transcript}
`;

    const openai = new OpenAI({ apiKey: openaiApiKey.value() });
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [{ role: "user", content: prompt }],
    });

    const script = response.choices[0]?.message?.content?.trim();

    if (!script) {
      throw new HttpsError("internal", "AI returned an empty recap script.");
    }

    await storyRef.update({
      script,
      targetMinutes,
      updatedAt: FieldValue.serverTimestamp(),
    });

    return {
      success: true,
      script,
      targetMinutes,
    };
  }
);

/**
 * 🎙️ CALLABLE FINALIZE STORY VOICE
 */
exports.finalizeStoryVoice = onCall(
  { region: "asia-southeast1" },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError("unauthenticated", "សូមចូលគណនីជាមុនសិន។");
    }

    const { storyId, chunks } = request.data || {};
    if (typeof storyId !== "string" || !storyId) {
      throw new HttpsError("invalid-argument", "storyId មិនត្រឹមត្រូវ។");
    }

    if (!Array.isArray(chunks) || chunks.length === 0) {
      throw new HttpsError("invalid-argument", "chunks មិនត្រឹមត្រូវ។");
    }

    const storySnap = await db.collection("stories").doc(storyId).get();
    if (!storySnap.exists) {
      throw new HttpsError("not-found", "រកមិនឃើញ Story ទេ។");
    }

    const story = storySnap.data();
    if ((story.uid || story.userId) !== request.auth.uid) {
      throw new HttpsError("permission-denied", "អ្នកមិនមែនជាម្ចាស់ Story នេះទេ។");
    }

    try {
      return await finalizeStoryVoice(storyId, chunks);
    } catch (err) {
      throw new HttpsError("internal", err.message);
    }
  }
);

exports.runRenderVideo = runRenderVideo;

/**
 * 🎬 CALLABLE RENDER FINAL VIDEO
 */
exports.renderFinalVideo = onCall(
  { region: "asia-southeast1", timeoutSeconds: 540, memory: "2GiB" },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError("unauthenticated", "សូមចូលគណនីជាមុនសិន។");
    }

    const { storyId } = request.data || {};
    if (typeof storyId !== "string" || !storyId) {
      throw new HttpsError("invalid-argument", "storyId មិនត្រឹមត្រូវ។");
    }

    const storySnap = await db.collection("stories").doc(storyId).get();
    if (!storySnap.exists) {
      throw new HttpsError("not-found", "រកមិនឃើញ Story ទេ។");
    }

    const story = storySnap.data();
    if ((story.uid || story.userId) !== request.auth.uid) {
      throw new HttpsError("permission-denied", "អ្នកមិនមែនជាម្ចាស់ Story នេះទេ។");
    }

    try {
      return await renderFinalVideo(storyId);
    } catch (err) {
      throw new HttpsError("internal", err.message);
    }
  }
);

